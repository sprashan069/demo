from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse

from app.routers import (account_vat, accounts, api_credentials, brand,
                         category, chargebee_token, check_balance, company,
                         company_detail, company_plan, contact, country,
                         country_state_city, currency, currency_rates, faq,
                         feature, landing_page, order, privacy_policy, product,
                         region, setting, style, style_category, sub_category,
                         term)
from app.routers.vendor import (vendor_account, vendor_banner,
                                vendor_banner_image, vendor_company_detail,
                                vendor_contact, vendor_contact_setting,
                                vendor_faq, vendor_frontend, vendor_header,
                                vendor_privacy_policy, vendor_publish,
                                vendor_setting, vendor_style,
                                vendor_style_category, vendor_term)

app = FastAPI()


async def catch_exceptions_middleware(request: Request, call_next):
    try:
        return await call_next(request)
    except Exception as e:
        with open("exceptions", "a") as f:
            # writing in the file
            f.write(str(e))
            f.write("\n\n")
            # closing the file
            f.close()

        res = {
            'detail': "Something went wrong. Please try again later or contact Administrator."
        }
        return JSONResponse(res, status_code=500)

#app.middleware('http')(catch_exceptions_middleware)

app.add_middleware(
    CORSMiddleware,
    allow_origins='*',
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(GZipMiddleware, minimum_size=1000)


@app.get("/", status_code=status.HTTP_200_OK)
def root():
    return "Microsite APIs"


app.include_router(landing_page.router)
app.include_router(contact.router)
app.include_router(company.router)
app.include_router(feature.router)
app.include_router(company_detail.router)
app.include_router(company_plan.router)
app.include_router(setting.router)
app.include_router(faq.router)
app.include_router(privacy_policy.router)
app.include_router(term.router)
app.include_router(country.router)
app.include_router(region.router)
app.include_router(currency.router)
app.include_router(brand.router)
app.include_router(category.router)
app.include_router(sub_category.router)
app.include_router(product.router)
app.include_router(style_category.router)
app.include_router(style.router)
app.include_router(order.router)
app.include_router(currency_rates.router)
app.include_router(vendor_frontend.router)
app.include_router(vendor_publish.router)
app.include_router(vendor_header.router)
app.include_router(vendor_banner.router)
app.include_router(vendor_banner_image.router)
app.include_router(vendor_setting.router)
app.include_router(vendor_style_category.router)
app.include_router(vendor_style.router)
app.include_router(vendor_faq.router)
app.include_router(vendor_term.router)
app.include_router(vendor_privacy_policy.router)
app.include_router(vendor_contact.router)
app.include_router(vendor_contact_setting.router)
app.include_router(accounts.router)
app.include_router(account_vat.router)
app.include_router(vendor_account.router)
app.include_router(vendor_company_detail.router)
app.include_router(chargebee_token.router)
app.include_router(api_credentials.router)
app.include_router(country_state_city.router)
app.include_router(check_balance.router)
