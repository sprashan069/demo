from typing import List

from app import schemas
from app.db import session
from fastapi import APIRouter, Depends, Response, status
from sqlalchemy.orm import Session

from ..crud import country

router = APIRouter(
    prefix="/countries",
    tags=['Countries']
)

get_db = session.get_db


@router.get('/', status_code=status.HTTP_200_OK, response_model=List[schemas.ShowCountry])
def all(db: Session = Depends(get_db)):
    return country.get_all(db)


@router.post('/', status_code=status.HTTP_201_CREATED, response_model=schemas.ShowCountry)
def create(request: schemas.Country, db: Session = Depends(get_db)):
    return country.create(request, db)


@router.delete('/{id}', status_code=status.HTTP_204_NO_CONTENT)
def destroy(id: str, db: Session = Depends(get_db)):
    country.destroy(id, db)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.put('/{id}', status_code=status.HTTP_202_ACCEPTED, response_model=schemas.ShowCountry)
def update(id: str, request: schemas.Country, db: Session = Depends(get_db)):
    return country.update(id, request, db)


@router.get('/{id}', status_code=status.HTTP_200_OK, response_model=schemas.ShowCountry)
def show(id: str, db: Session = Depends(get_db)):
    return country.show(id, db)
