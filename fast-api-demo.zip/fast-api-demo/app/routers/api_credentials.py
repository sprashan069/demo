from app import get_account_from_request
from app.db import session
from app.schemas import WhitelistIPDetail
from fastapi import APIRouter, Body, Depends, Request, status
from fastapi_pagination import Page, add_pagination, paginate
from sqlalchemy.orm import Session

from ..crud import api_credentials

router = APIRouter(
    tags=["Api Credentials"],
    prefix="/api-credentials"
)
get_db = session.get_db


@router.get('/', status_code=status.HTTP_200_OK)
def api_credential():
    return api_credentials.show()


@router.get('/whitelist', status_code=status.HTTP_200_OK, response_model=Page[WhitelistIPDetail])
def whitelist(request: Request, db: Session = Depends(get_db)):
    return paginate(api_credentials.whitelist(get_account_from_request(request, db), db))


@router.post('/whitelist', status_code=status.HTTP_200_OK)
def whitelist(request: Request, ip: str = Body(..., embed=True), db: Session = Depends(get_db)):
    return api_credentials.create(get_account_from_request(request, db), ip, db)


@router.delete('/whitelist', status_code=status.HTTP_200_OK)
def whitelist(request: Request, ip: str = Body(..., embed=True), db: Session = Depends(get_db)):
    return api_credentials.destroy(get_account_from_request(request, db), ip, db)


add_pagination(router)
