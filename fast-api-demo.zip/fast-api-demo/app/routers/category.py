from typing import List

from app import schemas
from app.db import session
from fastapi import APIRouter, Depends, Response, status
from sqlalchemy.orm import Session

from ..crud import category

router = APIRouter(
    prefix="/categories",
    tags=['Categories']
)

get_db = session.get_db


@router.get('/', status_code=status.HTTP_200_OK, response_model=List[schemas.ShowCategory])
def all(db: Session = Depends(get_db)):
    return category.get_all(db)


@router.post('/', status_code=status.HTTP_201_CREATED, response_model=schemas.ShowCategory)
def create(request: schemas.Category, db: Session = Depends(get_db)):
    return category.create(request, db)


@router.delete('/{id}', status_code=status.HTTP_204_NO_CONTENT)
def destroy(id: str, db: Session = Depends(get_db)):
    category.destroy(id, db)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.put('/{id}', status_code=status.HTTP_202_ACCEPTED, response_model=schemas.ShowCategory)
def update(id: str, request: schemas.UpdateCategory, db: Session = Depends(get_db)):
    return category.update(id, request, db)


@router.get('/{id}', status_code=status.HTTP_200_OK, response_model=schemas.ShowCategory)
def show(id: str, db: Session = Depends(get_db)):
    return category.show(id, db)
