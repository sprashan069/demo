from typing import List, Optional

from app import schemas
from app.db import session
from fastapi import (APIRouter, Depends, File, Form, Request, Response,
                     UploadFile, status)
from sqlalchemy.orm import Session

from ..crud import product

router = APIRouter(
    prefix="/products",
    tags=['Products']
)

get_db = session.get_db


@router.get('/', status_code=status.HTTP_200_OK, response_model=List[schemas.ProductDetail], summary="Product Detail", description="Get api return whole product details along with their all reference objects")
def all(db: Session = Depends(get_db)):
    return product.get_all(db)


@router.get('/super_admin', status_code=status.HTTP_200_OK, response_model=List[schemas.ProductList], summary="Product list for Super Admin", description="API return product detail as per their list page for super admin panel")
def super_admin(db: Session = Depends(get_db), is_default: bool = False):
    return product.super_admin(db, is_default)


@router.get('/super_admin_dropdown', status_code=status.HTTP_200_OK, response_model=List[schemas.GetProducts], summary="Product short detail", description="API return only product id, product name & their active status info")
def super_admin_dropdown(db: Session = Depends(get_db)):
    return product.super_admin_dropdown(db)


@router.post('/', status_code=status.HTTP_201_CREATED, response_model=schemas.ProductDetail)
def create(request: Request, name: str = Form(...), active: bool = File(...), is_default: bool = Form(...), expiration_period: int = Form(...), brand_id: str = Form(...), country_id: str = Form(...), region_id: str = Form(...), currency_id: str = Form(...), category_id: str = Form(...), sub_category_id: str = Form(...), style_id: Optional[str] = Form(None), style_image: Optional[UploadFile] = File(None), product_image: UploadFile = File(...), description: str = Form(...), description_ar: str = Form(...), terms: str = Form(...), terms_ar: str = Form(...), how_to_redeem: str = Form(...), how_to_redeem_ar: str = Form(...), mgc_product_id: Optional[str] = Form(None), is_quantity: bool = File(...), is_range: bool = File(...), is_fix_amount: bool = File(...), min_value: float = Form(...), max_value: float = Form(...), denominations: str = Form(...), is_email: bool = File(...), is_sms: bool = File(...), db: Session = Depends(get_db)):
    return product.create(name, active, is_default, expiration_period, brand_id, country_id, region_id, currency_id, category_id, sub_category_id, style_id, style_image, product_image, description, description_ar, terms, terms_ar, how_to_redeem, how_to_redeem_ar, mgc_product_id, is_quantity, is_range, is_fix_amount, min_value, max_value, denominations, is_email, is_sms, request, db)


@router.delete('/{id}', status_code=status.HTTP_204_NO_CONTENT)
def destroy(id: str, db: Session = Depends(get_db)):
    product.destroy(id, db)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.put('/{id}', status_code=status.HTTP_202_ACCEPTED, response_model=schemas.ProductDetail)
def update(id: str, name: Optional[str] = Form(None), active: Optional[bool] = File(None), is_default: Optional[bool] = Form(None), expiration_period: Optional[int] = Form(None), brand_id: Optional[str] = Form(None), country_id: Optional[str] = Form(None), region_id: Optional[str] = Form(None), currency_id: Optional[str] = Form(None), category_id: Optional[str] = Form(None), sub_category_id: Optional[str] = Form(None), style_id: Optional[str] = Form(None), style_image: Optional[UploadFile] = File(None), product_image: Optional[UploadFile] = File(None), description: Optional[str] = Form(None), description_ar: Optional[str] = Form(None), terms: Optional[str] = Form(None), terms_ar: Optional[str] = Form(None), how_to_redeem: Optional[str] = Form(None), how_to_redeem_ar: Optional[str] = Form(None), mgc_product_id: Optional[str] = Form(None), is_quantity: Optional[bool] = File(None), is_range: Optional[bool] = File(None), is_fix_amount: Optional[bool] = File(None), min_value: Optional[float] = Form(None), max_value: Optional[float] = Form(None), denominations: Optional[str] = Form(None), admin_denominations: Optional[str] = Form(None), is_email: Optional[bool] = File(None), is_sms: Optional[bool] = File(None), db: Session = Depends(get_db)):
    return product.update(id, name, active, is_default, expiration_period, brand_id, country_id, region_id, currency_id, category_id, sub_category_id, style_id, style_image, product_image, description, description_ar, terms, terms_ar, how_to_redeem, how_to_redeem_ar, mgc_product_id, is_quantity, is_range, is_fix_amount, min_value, max_value, denominations, admin_denominations, is_email, is_sms, db)


@router.get('/{id}', status_code=status.HTTP_200_OK, response_model=schemas.ProductDetail)
def show(id: str, db: Session = Depends(get_db)):
    return product.show(id, db)
