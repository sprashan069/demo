from typing import List

from app import schemas
from app.db import session
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..crud import accounts

router = APIRouter(
    tags=["Accounts"],
    prefix="/accounts"
)

get_db = session.get_db


@router.get('/', response_model=List[schemas.AllAccountDetail])
def all(db: Session = Depends(get_db)):
    return accounts.get_all(db)


@router.get('/{id}', response_model=schemas.AllAccountDetail)
def all(id: str, db: Session = Depends(get_db)):
    return accounts.get_account(id, db)


@router.put("/{id}", response_model=schemas.AllAccountDetail)
def update(id: str, account_obj: schemas.AccountVat, db: Session = Depends(get_db)):
    return accounts.update(id, account_obj, db)
