from app import schemas
from app.crud import privacy_policy
from app.db import session
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

router = APIRouter(prefix="/privacy-policies", tags=["Privacy Policy"])

get_db = session.get_db


@router.put("/", status_code=status.HTTP_202_ACCEPTED, response_model=schemas.PrivacyPolicy)
def update(request: schemas.PrivacyPolicy, db: Session = Depends(get_db)):
    return privacy_policy.update(request, db)


@router.get("/", status_code=status.HTTP_200_OK, response_model=schemas.PrivacyPolicy)
def show(db: Session = Depends(get_db)):
    return privacy_policy.show(db)
