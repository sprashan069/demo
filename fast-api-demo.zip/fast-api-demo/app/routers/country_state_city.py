from typing import List

from app import schemas
from app.crud import country_state_city
from app.db import session
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

router = APIRouter(tags=["Country State City"])

get_db = session.get_db


@router.get("/countries", status_code=status.HTTP_200_OK, response_model=List[schemas.country])
def all(db: Session = Depends(get_db)):
    return country_state_city.get_countries(db)


@router.get("/states/{country_id}", status_code=status.HTTP_200_OK, response_model=List[schemas.States])
def all(country_id: int, db: Session = Depends(get_db)):
    return country_state_city.get_state(country_id, db)


@router.get("/cities/{state_id}", status_code=status.HTTP_200_OK, response_model=List[schemas.Cities])
def all(state_id: int, db: Session = Depends(get_db)):
    return country_state_city.get_cities(state_id, db)
