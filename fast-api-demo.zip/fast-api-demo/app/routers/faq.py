from app import schemas
from app.crud import faq
from app.db import session
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

router = APIRouter(prefix="/faqs", tags=["FAQ"])

get_db = session.get_db


@router.put("/", status_code=status.HTTP_202_ACCEPTED, response_model=schemas.ShowFAQ)
def update(request: schemas.ShowFAQ, db: Session = Depends(get_db)):
    return faq.update(request, db)


@router.get("/", status_code=status.HTTP_200_OK, response_model=schemas.ShowFAQ)
def show(db: Session = Depends(get_db)):
    return faq.show(db)
