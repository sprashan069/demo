from app import schemas
from app.crud import landing_page
from app.db import session
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

router = APIRouter(prefix="/frontend-site", tags=["Microsite Landing Page"])

get_db = session.get_db


@router.get("/", status_code=status.HTTP_200_OK, response_model=schemas.LandingPage)
def microsite_landing_page(db: Session = Depends(session.get_db)):
    return landing_page.get(db)


@router.get("/privacy-policy", status_code=status.HTTP_200_OK, response_model=schemas.LandingPagePrivacyPolicy)
def microsite_privacy_policy(db: Session = Depends(session.get_db)):
    return landing_page.privacy_policy(db)


@router.get("/terms-and-conditions", status_code=status.HTTP_200_OK, response_model=schemas.LandingPageTerm)
def microsite_terms_and_conditions(db: Session = Depends(session.get_db)):
    return landing_page.terms_and_conditions(db)
