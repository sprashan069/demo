from app import schemas
from app.crud import contact
from app.db import session
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

router = APIRouter(prefix="/contacts", tags=["Contact"])

get_db = session.get_db


@router.get("/", status_code=status.HTTP_200_OK, response_model=schemas.ContactList)
def all(db: Session = Depends(get_db)):
    return contact.show(db)


@router.post('/', status_code=status.HTTP_201_CREATED, response_model=schemas.ShowContacts)
def create(request: schemas.Contacts, db: Session = Depends(get_db)):
    return contact.create(request, db)


@router.get("/{id}", status_code=status.HTTP_200_OK, response_model=schemas.ShowContacts)
def show(id: str, db: Session = Depends(get_db)):
    return contact.index(id, db)
