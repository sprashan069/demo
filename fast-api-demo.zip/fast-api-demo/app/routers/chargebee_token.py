from app import get_account_from_request
from app.db import session
from fastapi import APIRouter, Body, Depends, Request, status
from sqlalchemy.orm import Session

from ..crud import chargebee_token

router = APIRouter(
    prefix="/chargebee-subscription",
    tags=['ChargeBee Subscription']
)

get_db = session.get_db


@router.post('/', status_code=status.HTTP_201_CREATED)
def create(request: Request, token: str = Body(..., embed=True), db: Session = Depends(get_db)):
    return chargebee_token.create(get_account_from_request(request, db), token, db)
