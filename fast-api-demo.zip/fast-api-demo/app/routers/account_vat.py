from typing import List

from app import schemas
from app.db import session
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from ..crud import account_vat

router = APIRouter(
    tags=["Accounts VAT"],
    prefix="/accounts-vat"
)

get_db = session.get_db


@router.post('/', status_code= status.HTTP_201_CREATED)
def create(request:schemas.AccountVat, db:Session = Depends(get_db)):
    return account_vat.create(request, db)

@router.get('/', response_model = List[schemas.AccountVat])
def all(db: Session=Depends(get_db)):
    return account_vat.show(db)

@router.put('/{id}', status_code=status.HTTP_202_ACCEPTED)
def update(id, request: schemas.AccountVat, db: Session = Depends(get_db)):
    return account_vat.update(id, request,db)
