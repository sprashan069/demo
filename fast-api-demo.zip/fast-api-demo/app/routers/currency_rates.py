from app import get_account_from_request
from app.crud import currency_rates
from app.db import session
from fastapi import APIRouter, Depends, Request, status
from sqlalchemy.orm import Session

router = APIRouter(
    prefix="/currency_rates",
    tags=['Currency Rates']
)

get_db = session.get_db


@router.get('/{currency}', status_code=status.HTTP_200_OK)
def all(currency: str, request: Request, db: Session = Depends(get_db)):
    return currency_rates.show(currency, get_account_from_request(request, db), db)
