from typing import Optional

from app import schemas
from app.crud import setting
from app.db import session
from fastapi import APIRouter, Depends, File, Form, Request, UploadFile, status
from sqlalchemy.orm import Session

router = APIRouter(prefix="/setting", tags=["Setting"])

get_db = session.get_db


@router.get("/", status_code=status.HTTP_200_OK, response_model=schemas.Setting)
def show(db: Session = Depends(get_db)):
    return setting.show(db)


@router.put("/", status_code=status.HTTP_202_ACCEPTED, response_model=schemas.Setting)
async def update(header_title: Optional[str] = Form(None), header_logo: Optional[UploadFile] = File(None), footer_logo: Optional[UploadFile] = File(None), copy_right: Optional[str] = Form(None), db: Session = Depends(get_db)):
    return setting.update(header_title, header_logo, footer_logo, copy_right, db)


@router.put("/contact_info", status_code=status.HTTP_202_ACCEPTED, response_model=schemas.Setting)
def update_contact(contact_info: schemas.CompanyContactList, db: Session = Depends(get_db)):
    return setting.update_contact(contact_info, db)


@router.put("/footer_menu", status_code=status.HTTP_202_ACCEPTED, response_model=schemas.Setting)
def update_footer(footer_menu: schemas.FooterMenuList, db: Session = Depends(get_db)):
    return setting.update_footer(footer_menu, db)


@router.put("/social_media_links", status_code=status.HTTP_202_ACCEPTED, response_model=schemas.Setting)
async def update_social_media_links(request: Request, db: Session = Depends(get_db)):
    payload = await request.form()
    return setting.update_social_media_links(payload, db)
