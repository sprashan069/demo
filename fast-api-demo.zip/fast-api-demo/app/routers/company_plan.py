from app import schemas
from app.crud import company_plan
from app.db import session
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

router = APIRouter(prefix="/pricing", tags=["Pricing"])

get_db = session.get_db


@router.put(
    "/", status_code=status.HTTP_202_ACCEPTED, response_model=schemas.ShowCompanyPlan
)
async def update(request: schemas.ShowCompanyPlan, db: Session = Depends(get_db)):
    return company_plan.update(request, db)


@router.get(
    "/", status_code=status.HTTP_200_OK, response_model=schemas.ShowCompanyPlan
)
def show(db: Session = Depends(get_db)):
    return company_plan.show(db)
