from typing import List

from app import schemas
from app.db import session
from fastapi import APIRouter, Depends, Response, status
from sqlalchemy.orm import Session

from ..crud import sub_category

router = APIRouter(
    prefix="/sub-categories",
    tags=['SubCategories']
)

get_db = session.get_db


@router.get('/', status_code=status.HTTP_200_OK, response_model=List[schemas.ShowSubCategory])
def all(category_id: str = None, db: Session = Depends(get_db)):
    return sub_category.get_all(category_id, db)


@router.post('/', status_code=status.HTTP_201_CREATED, response_model=schemas.ShowSubCategory)
def create(request: schemas.SubCategory, db: Session = Depends(get_db)):
    return sub_category.create(request, db)


@router.delete('/{id}', status_code=status.HTTP_204_NO_CONTENT)
def destroy(id: str, db: Session = Depends(get_db)):
    sub_category.destroy(id, db)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.put('/{id}', status_code=status.HTTP_202_ACCEPTED, response_model=schemas.ShowSubCategory)
def update(id: str, request: schemas.UpdateSubCategory, db: Session = Depends(get_db)):
    return sub_category.update(id, request, db)


@router.get('/{id}', status_code=status.HTTP_200_OK, response_model=schemas.ShowSubCategory)
def show(id: str, db: Session = Depends(get_db)):
    return sub_category.show(id, db)
