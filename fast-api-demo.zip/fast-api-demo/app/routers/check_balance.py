from app import get_account_from_request
from app.db import session
from fastapi import APIRouter, Depends, Request, status
from sqlalchemy.orm import Session

from ..crud import check_balance

router = APIRouter(
    tags=["Check Balance"],
    prefix="/check-balance"
)
get_db = session.get_db


@router.get('/', status_code=status.HTTP_200_OK)
def show(request: Request, giftcard_number: str, db: Session = Depends(get_db)):
    return check_balance.get(get_account_from_request(request, db), giftcard_number, db)
