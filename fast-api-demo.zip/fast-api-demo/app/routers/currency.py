from typing import List

from app import schemas
from app.db import session
from fastapi import APIRouter, Depends, Response, status
from sqlalchemy.orm import Session

from ..crud import currency

router = APIRouter(
    prefix="/currencies",
    tags=['Currencies']
)

get_db = session.get_db


@router.get('/', response_model=List[schemas.ShowCurrency])
def all(country_id: str = None, db: Session = Depends(get_db)):
    return currency.get_all(country_id, db)


@router.post('/', status_code=status.HTTP_201_CREATED, response_model=schemas.ShowCurrency)
def create(request: schemas.UpdateCurrency, db: Session = Depends(get_db)):
    return currency.create(request, db)


@router.delete('/{id}', status_code=status.HTTP_204_NO_CONTENT)
def destroy(id: str, db: Session = Depends(get_db)):
    currency.destroy(id, db)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.put('/{id}', status_code=status.HTTP_202_ACCEPTED, response_model=schemas.ShowCurrency)
def update(id: str, request: schemas.UpdateCurrency, db: Session = Depends(get_db)):
    return currency.update(id, request, db)


@router.get('/{id}', status_code=status.HTTP_200_OK, response_model=schemas.ShowCurrency)
def show(id: str, db: Session = Depends(get_db)):
    return currency.show(id, db)
