from typing import List

from app import schemas
from app.db import session
from fastapi import APIRouter, Depends, Response, status
from sqlalchemy.orm import Session

from ..crud import brand

router = APIRouter(
    prefix="/brands",
    tags=['Brands']
)

get_db = session.get_db


@router.get('/', response_model=List[schemas.ShowBrand])
def all(db:Session = Depends(get_db)):
    return brand.get_all( db)


@router.post('/', status_code=status.HTTP_201_CREATED, response_model=schemas.ShowBrand)
def create(request:schemas.Brand, db:Session = Depends(get_db)):
    return brand.create(request,db)


@router.delete('/{id}', status_code=status.HTTP_204_NO_CONTENT)
def destroy(id: str, db: Session = Depends(get_db)):
    brand.destroy(id, db)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.put('/{id}', status_code=status.HTTP_202_ACCEPTED, response_model=schemas.ShowBrand)
def update(id: str, request: schemas.UpdateBrand, db: Session = Depends(get_db)):
    return brand.update(id, request, db)


@router.get('/{id}', status_code=status.HTTP_200_OK, response_model=schemas.ShowBrand)
def show(id: str, db: Session = Depends(get_db)):
    return brand.show(id, db)
