from app import get_account_from_request, schemas
from app.crud import order
from app.db import session
from fastapi import APIRouter, Depends, Request, Response, status
from sqlalchemy.orm import Session

router = APIRouter(
    prefix="/orders",
    tags=['Order']
)

get_db = session.get_db


@router.get('/order_status', status_code=status.HTTP_200_OK, response_model=schemas.OrderStatusCount)
def order_status(request: Request, db: Session = Depends(get_db)):
    return order.order_status(get_account_from_request(request, db), db)


@router.get('/', status_code=status.HTTP_200_OK, response_model=schemas.OrderList)
def index(request: Request, fromDate: str = None, toDate: str = None, db: Session = Depends(get_db), skip: int = 0, limit: int = 50):
    return order.index(get_account_from_request(request, db), db, skip, limit, fromDate, toDate)


@router.post('/', status_code=status.HTTP_202_ACCEPTED, response_model=schemas.OrderFetch, description="Language should be en or ar. Bydefault it's en")
def create(order_obj: schemas.PlaceOrder, request: Request, db: Session = Depends(get_db)):
    return order.create(order_obj, get_account_from_request(request, db), db)


@router.post('/order_payment/{orderId}', status_code=status.HTTP_202_ACCEPTED, response_model=schemas.OrderFetch)
async def order_payment(orderId: str, order_payment_obj: schemas.OrderPayment, request: Request, db: Session = Depends(get_db)):
    return await order.order_payment(orderId, order_payment_obj, get_account_from_request(request, db), db)


@router.get('/{orderId}', status_code=status.HTTP_200_OK, response_model=schemas.OrderFetch)
def show(orderId: str, request: Request, db: Session = Depends(get_db)):
    return order.show(orderId, get_account_from_request(request, db), db)


@router.post('/cancel_order/{orderId}', status_code=status.HTTP_204_NO_CONTENT)
def cancel_order(orderId: str, request: Request, reason: schemas.OrderCancel, db: Session = Depends(get_db)):
    order.cancel_order(
        orderId, get_account_from_request(request, db), reason, db)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.put('/reprocess_order/{orderId}', status_code=status.HTTP_202_ACCEPTED, response_model=schemas.OrderFetch)
async def reprocess_order(orderId: str, request: Request, db: Session = Depends(get_db)):
    return await order.reprocess_order(orderId, get_account_from_request(request, db), db)


@router.post('/resend_mail/{orderId}', status_code=status.HTTP_204_NO_CONTENT)
async def resend_email(orderId: str, request: Request, db: Session = Depends(get_db)):
    await order.resend_email(orderId, get_account_from_request(request, db), db)
    return Response(status_code=status.HTTP_204_NO_CONTENT)
