from typing import Optional

from app import schemas
from app.crud import company
from app.db import session
from fastapi import APIRouter, Depends, File, Form, UploadFile, status
from sqlalchemy.orm import Session

router = APIRouter(prefix="/home-page", tags=["Home Page"])

get_db = session.get_db


@router.put("/", status_code=status.HTTP_202_ACCEPTED, response_model=schemas.HomePage)
def update(
    banner_title: Optional[str] = Form(None),
    get_started_flag: Optional[bool] = Form(True),
    banner_image: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db),
):
    return company.update(banner_title, get_started_flag, banner_image, db)


@router.get("/", status_code=status.HTTP_200_OK, response_model=schemas.HomePage)
def show(db: Session = Depends(get_db)):
    return company.show(db)
