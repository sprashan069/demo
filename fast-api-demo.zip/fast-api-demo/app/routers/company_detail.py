from typing import List, Optional

from app import schemas
from app.crud import company_detail
from app.db import session
from fastapi import (APIRouter, Depends, File, Form, Response, UploadFile,
                     status)
from sqlalchemy.orm import Session

router = APIRouter(prefix="/how-it-works", tags=["How It Works"])

get_db = session.get_db


@router.get('/', status_code=status.HTTP_200_OK, response_model=List[schemas.ShowCompanyDetail])
def show(db: Session = Depends(get_db)):
    return company_detail.show(db)


@router.post('/add', status_code=status.HTTP_201_CREATED, response_model=schemas.ShowCompanyDetail)
def add_company_detail(title: str = Form(...), sub_title: Optional[str] = Form(None), description: str = Form(...), image: UploadFile = File(...), active: bool = File(...), db: Session = Depends(get_db)):
    return company_detail.add_company_detail(title, sub_title, description, image, active, db)


@router.put(
    "/update/{id}", status_code=status.HTTP_202_ACCEPTED, response_model=schemas.ShowCompanyDetail)
async def update_company_detail(id: str, title: Optional[str] = Form(None), sub_title: Optional[str] = Form(None), description: Optional[str] = Form(None), image: Optional[UploadFile] = File(None), active: Optional[bool] = File(None), db: Session = Depends(get_db)):
    return company_detail.update_company_detail(id, title, sub_title, description, image, active, db)


@router.delete(
    "/delete/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_company_detail(id: str, db: Session = Depends(get_db)):
    company_detail.delete_company_detail(id, db)
    return Response(status_code=status.HTTP_204_NO_CONTENT)
