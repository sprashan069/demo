from typing import List, Optional

from app import schemas
from app.db import session
from fastapi import (APIRouter, Depends, File, Form, Response, UploadFile,
                     status)
from sqlalchemy.orm import Session

from ..crud import style

router = APIRouter(
    prefix="/styles",
    tags=['Styles']
)

get_db = session.get_db


@router.get('/', status_code=status.HTTP_200_OK, response_model=List[schemas.StyleDetail])
def all(style_category_id: str = None, db: Session = Depends(get_db)):
    return style.get_all(style_category_id, db)


@router.post('/', status_code=status.HTTP_201_CREATED, response_model=schemas.StyleDetail)
def create(name: str = Form(None), name_ar: str = Form(None), image: UploadFile = File(None), image_ar: UploadFile = File(None), active: bool = File(...), style_category_id: str = Form(...), db: Session = Depends(get_db)):
    return style.create(name, name_ar, image, image_ar, active, style_category_id, db)


@router.delete('/{id}', status_code=status.HTTP_204_NO_CONTENT)
def destroy(id: str, db: Session = Depends(get_db)):
    style.destroy(id, db)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.put('/{id}', status_code=status.HTTP_202_ACCEPTED, response_model=schemas.StyleDetail)
def update(id: str, name: Optional[str] = Form(None), name_ar: str = Form(None), image: Optional[UploadFile] = File(None), image_ar: UploadFile = File(None), active: Optional[bool] = File(None), style_category_id: Optional[str] = Form(None), db: Session = Depends(get_db)):
    return style.update(id, name, name_ar, image, image_ar, active, style_category_id, db)


@router.get('/{id}', status_code=status.HTTP_200_OK, response_model=schemas.StyleDetail)
def show(id: str, db: Session = Depends(get_db)):
    return style.show(id, db)
