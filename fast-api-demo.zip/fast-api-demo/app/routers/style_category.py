from typing import List, Optional

from app import schemas
from app.db import session
from fastapi import (APIRouter, Depends, File, Form, Response, UploadFile,
                     status)
from sqlalchemy.orm import Session

from ..crud import style_category

router = APIRouter(
    prefix="/style-categories",
    tags=['StyleCategories']
)

get_db = session.get_db


@router.get('/', status_code=status.HTTP_200_OK, response_model=List[schemas.StyleCategoryDetail])
def all(db: Session = Depends(get_db)):
    return style_category.get_all(db)


@router.post('/', status_code=status.HTTP_201_CREATED, response_model=schemas.StyleCategoryDetail)
def create(name: str = Form(None), name_ar: str = Form(None), image: UploadFile = File(...), active: bool = File(...), db: Session = Depends(get_db)):
    return style_category.create(name, name_ar, image, active, db)


@router.delete('/{id}', status_code=status.HTTP_204_NO_CONTENT)
def destroy(id: str, db: Session = Depends(get_db)):
    style_category.destroy(id, db)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.put('/{id}', status_code=status.HTTP_202_ACCEPTED, response_model=schemas.StyleCategoryDetail)
def update(id: str, name: Optional[str] = Form(None), name_ar: Optional[str] = Form(None), image: Optional[UploadFile] = File(None), active: Optional[bool] = File(None), db: Session = Depends(get_db)):
    return style_category.update(id, name, name_ar, image, active, db)


@router.get('/{id}', status_code=status.HTTP_200_OK, response_model=schemas.StyleCategoryDetail)
def show(id: str, db: Session = Depends(get_db)):
    return style_category.show(id, db)
