from typing import List, Optional

from app import schemas
from app.crud import feature
from app.db import session
from fastapi import (APIRouter, Depends, File, Form, Response, UploadFile,
                     status)
from sqlalchemy.orm import Session

router = APIRouter(prefix="/features", tags=["Features"])

get_db = session.get_db


@router.get('/', status_code=status.HTTP_200_OK, response_model=List[schemas.Feature])
def show(db: Session = Depends(get_db)):
    return feature.show(db)


@router.post('/add', status_code=status.HTTP_201_CREATED, response_model=schemas.Feature)
def add_feature(title: str = Form(...), description: str = Form(...), image: UploadFile = File(...), active: bool = File(...), db: Session = Depends(get_db)):
    return feature.add_feature(title, description, image, active, db)


@router.put(
    "/update/{id}", status_code=status.HTTP_202_ACCEPTED, response_model=schemas.Feature)
def update_feature(id: str, title: Optional[str] = Form(None), description: Optional[str] = Form(None), image: Optional[UploadFile] = File(None), active: Optional[bool] = File(None), db: Session = Depends(get_db)):
    return feature.update_feature(id, title, description, image, active, db)


@router.delete(
    "/delete/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_feature(id: str, db: Session = Depends(get_db)):
    feature.delete_feature(id, db)
    return Response(status_code=status.HTTP_204_NO_CONTENT)
