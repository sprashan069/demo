import os
import shutil
import time
from urllib.parse import urlparse

import boto3
import jwt
from fastapi import HTTPException, status
from fastapi_mail import ConnectionConfig

from app import models

s3 = boto3.client('s3', )

temp_dir = os.path.join(os.getcwd(), 'tmp')

if not os.path.exists(temp_dir):
    os.mkdir(temp_dir)


def upload_image(file):
    if file:
        if not file.filename.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp', '.gif')):
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY,
                                detail="Uploaded file is not a valid image.")

        # File path to save the image
        file_name = str(round(time.time() * 1000)) + "_" + \
            file.filename.replace(" ", "-")
        file_save_path = os.path.join(temp_dir, file_name)

        # Save image at the above path
        with open(file_save_path, 'wb') as buffer:
            shutil.copyfileobj(file.file, buffer)

        s3_bucket_name = os.environ.get('AWS_S3_BUCKET')

        s3.upload_file(
            file_save_path, s3_bucket_name, file_name, ExtraArgs={'ACL': 'public-read'})

        os.remove(file_save_path)

        bucket_location = boto3.client(
            's3').get_bucket_location(Bucket=s3_bucket_name)
        object_url = "https://s3-{0}.amazonaws.com/{1}/{2}".format(
            bucket_location['LocationConstraint'],
            s3_bucket_name,
            file_name)
        return object_url
    return None


def get_account_from_request(request, db):
    try:
        hostname = urlparse(request.headers['origin']).netloc
        account = db.query(models.Account).filter(
            models.Account.domain == hostname).first()
        if account:
            return account.id
    except Exception:
        pass

    try:
        authorization_token = request.headers['authorization']
        account_data = jwt.decode(authorization_token, options={
            "verify_signature": False})
        tenant_id = account_data["custom:tenantId"]
        if not tenant_id:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Tenant ID missing!!"
            )
        return tenant_id
    except KeyError:
        raise HTTPException(
            status.HTTP_403_FORBIDDEN, detail="Unauthorized"
        )
    except jwt.exceptions.DecodeError:
        raise HTTPException(
            status.HTTP_403_FORBIDDEN, detail="Invalid token"
        )


# Email credentials
email_send = ConnectionConfig(
    MAIL_TLS=True,
    MAIL_SSL=False,
    USE_CREDENTIALS=True,
    MAIL_USERNAME=os.environ.get('MAIL_USERNAME'),
    MAIL_PASSWORD=os.environ.get('MAIL_PASSWORD'),
    MAIL_FROM=os.environ.get('MAIL_FROM'),
    MAIL_PORT=os.environ.get('MAIL_PORT'),
    MAIL_SERVER=os.environ.get('MAIL_SERVER'),
    TEMPLATE_FOLDER='app/email'
)
