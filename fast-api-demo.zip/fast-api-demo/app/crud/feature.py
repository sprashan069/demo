import datetime

from app import models, upload_image
from app.crud.base import get_ref_no
from fastapi import HTTPException, status
from sqlalchemy.orm import Session


def show(db: Session):
    features = db.query(models.FeatureList).order_by(
        models.FeatureList.created_at.asc()).all()
    for feature in features:
        feature.id = feature.ref_id
    return features


def add_feature(title, description, image, active, db: Session):
    ref_id = get_ref_no("FLT")
    obj = models.FeatureList(title=title,
                             description=description,
                             active=active,
                             image=upload_image(image), ref_id=str(ref_id))

    db.add(obj)
    db.commit()
    db.refresh(obj)
    obj.id = obj.ref_id
    return obj


def update_feature(id, title, description, image, active, db: Session):
    obj = db.query(models.FeatureList).filter(
        models.FeatureList.ref_id == id).first()

    if not obj:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Object with that id not found.")

    if title:
        obj.title = title
    if description:
        obj.description = description
    if active is not None:
        obj.active = active
    if image:
        obj.image = upload_image(image)
    db.add(obj)
    db.commit()
    db.refresh(obj)
    obj.id = obj.ref_id
    return obj.__dict__


def delete_feature(id: str, db: Session):
    obj = db.query(models.FeatureList).filter(
        models.FeatureList.ref_id == id).first()

    if not obj:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Object with that id not found.")

    obj.deleted_at = datetime.datetime.utcnow()
    db.add(obj)
    db.commit()
