import os

from app import models
from app.db.session import SessionLocal
from numpy import genfromtxt
from sqlalchemy.orm import Session
from worker import app


def get_countries(db: Session):
    countries = db.query(models.Countries).order_by(
        models.Countries.name.asc()).all()
    return countries


def get_state(country_id, db: Session):
    states = db.query(models.States).filter_by(country_id=country_id).order_by(
        models.States.name.asc()).all()
    return states


def get_cities(state_id, db: Session):
    cities = db.query(models.Cities).filter_by(state_id=state_id).order_by(
        models.Cities.name.asc()).all()
    return cities


def load_data(file_name):
    data = genfromtxt(file_name, dtype=None, delimiter=',', skip_header=1, encoding=None)
    return data.tolist()


def save_db(file_name, callback):
    db = SessionLocal()
    try:
        file_name = os.path.join("fixtures/", file_name)
        csv_data = load_data(file_name)
        callback(csv_data, db)
        db.commit()  # Attempt to commit all the records
    except:
        db.rollback()  # Rollback the changes on error
    finally:
        db.close()  # Close the connection


def country_obj(csv_data, db):
    for i in csv_data:
        record = models.Countries(**{
            'id': i[0],
            'name': i[1],
            'iso3': i[2],
            'iso2': i[3],
            'phone_code': i[4],
            'capital': i[5],
            'currency': i[6],
            'region': i[7],
            'latitude': i[8],
            'longitude': i[9]
        })
        db.add(record)  # Add all the records


def save_country_data():
    save_db("countries.csv", country_obj)


def states_obj(csv_data, db):
    for i in csv_data:
        record = models.States(**{
            'id': i[0],
            'name': i[1],
            'country_id': i[2],
            'country_code': i[3],
            'state_code': i[4],
            'latitude': i[5],
            'longitude': i[6]
        })
        db.add(record)  # Add all the records


def save_state_data():
    save_db("states.csv", states_obj)


def city_obj(csv_data, db):
    for i in csv_data:
        record = models.Cities(**{
            'id': i[0],
            'name': i[1],
            'state_id': i[2],
            'state_code': i[3],
            'country_id': i[4],
            'country_code': i[5],
            'latitude': i[6],
            'longitude': i[7]
        })
        db.add(record)  # Add all the records


def save_city_data():
    save_db("cities.csv", city_obj)


@app.task
def store_data():
    db = SessionLocal()
    country_data = db.query(models.Countries).first()
    state_data = db.query(models.States).first()
    city_data = db.query(models.Cities).first()
    if not country_data:
        save_country_data()
    if not state_data:
        save_state_data()
    if not city_data:
        save_city_data()
