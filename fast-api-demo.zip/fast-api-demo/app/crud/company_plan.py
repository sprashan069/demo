import datetime

from app import models
from app.crud.base import get_ref_no
from fastapi import HTTPException, status
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session


def get_obj(db):
    plan = db.query(models.CompanyPlan).order_by(
        models.CompanyPlan.created_at.asc()).first()
    obj = {} if not plan else plan.__dict__

    obj["plan_lists"] = []
    for plan_list in db.query(models.CompanyPlanList).order_by(
            models.CompanyPlanList.created_at.asc()).all():
        obj["plan_lists"].append(plan_list.__dict__)
        plan_list.id = plan_list.ref_id
    return obj


def save_obj(new_obj, db):
    try:
        db.add(new_obj)
        db.commit()
        db.refresh(new_obj)
        return new_obj

    except SQLAlchemyError as e:
        error = str(e.__dict__["orig"])
        return HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def create_plan(plan, plan_id):
    ref_id = get_ref_no("PLA")
    new_object = models.CompanyPlanList(
        ref_id=str(ref_id),
        active=plan.active,
        company_plan_id=plan_id,
        title=plan.title,
        sub_title=plan.sub_title,
        price=plan.price,
        feature_list=plan.feature_list,
        button_text=plan.button_text,
    )
    return new_object


def list_obj(db, ref_id):
    return (
        db.query(models.CompanyPlanList)
        .filter(models.CompanyPlanList.ref_id == ref_id)
        .first()
    )


def update(request, db: Session):
    objects = db.query(models.CompanyPlan).all()
    plans = request.plan_lists
    if not objects:
        ref_id = get_ref_no("CMP")
        new_object = models.CompanyPlan(
            ref_id=str(ref_id),
            title=request.title,
            description=request.description,
        )
        obj = save_obj(new_object, db)
        plan_id = obj.ref_id

        for plan in plans:
            new_object = create_plan(plan, plan_id)
            save_obj(new_object, db)
    else:
        obj = objects[0]
        if request.title or request.title == '':
            obj.title = request.title
        if request.description or request.description == '':
            obj.description = request.description
        save_obj(obj, db)

        list_ids = []
        list_id = []
        plan_id = obj.ref_id
        for plan_list in db.query(models.CompanyPlanList).all():
            list_ids.append(plan_list.ref_id)
        if plans:
            for plan in plans:
                reference_no = plan.id
                if not reference_no:
                    plan_object = create_plan(plan, plan_id)
                else:
                    plan_object = list_obj(db, reference_no)
                    if not plan_object:
                        raise HTTPException(
                            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Object with {reference_no} not found.",
                        )
                    list_id.append(reference_no)
                    if plan.active is not None:
                        plan_object.active = plan.active
                    if plan_id:
                        plan_object.company_plan_id = plan_id
                    if plan.title or plan.title == "":
                        plan_object.title = plan.title
                    if plan.sub_title or plan.sub_title == "":
                        plan_object.sub_title = plan.sub_title
                    if plan.price or plan.price == "":
                        plan_object.price = plan.price
                    if plan.feature_list or plan.feature_list == "":
                        plan_object.feature_list = plan.feature_list
                    if plan.button_text or plan.button_text == "":
                        plan_object.button_text = plan.button_text

                if plan_object:
                    obj = save_obj(plan_object, db)

        remaining = [item for item in list_ids if item not in list_id]

        if remaining:
            for ref_id in remaining:
                plan = list_obj(db, ref_id)

                if not plan:
                    raise HTTPException(
                        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                        detail=f"Object with {ref_id} not found.",
                    )

                plan.deleted_at = datetime.datetime.utcnow()
                db.add(plan)
                db.commit()

    return get_obj(db)


def show(db: Session):
    return get_obj(db)
