import datetime

from app import models
from app.crud.base import get_ref_no
from fastapi import HTTPException, status
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session


def get_obj(db):
    obj = {}
    obj["faqs"] = []
    for record in db.query(models.FAQ).order_by(
            models.FAQ.created_at.asc()).all():
        obj["faqs"].append(record.__dict__)
    return obj


def save_obj(new_obj, db):
    try:
        db.add(new_obj)
        db.commit()
        db.refresh(new_obj)
        obj = get_obj(db)
        return obj

    except SQLAlchemyError as e:
        error = str(e.__dict__["orig"])
        return error


def list_obj(db, ref_id):
    return db.query(models.FAQ).filter(models.FAQ.ref_id == ref_id).first()


def update(request, db: Session):
    records = request.faqs

    list_ids = []
    list_id = []
    for faq in db.query(models.FAQ).all():
        list_ids.append(faq.ref_id)
    if records:
        for record in records:
            reference_no = record.ref_id
            if not reference_no:
                ref_id = get_ref_no("FAQ")
                faq_object = models.FAQ(
                    ref_id=str(ref_id),
                    active=record.active,
                    sort_order=record.sort_order,
                    question=record.question,
                    answer=record.answer,
                )
            else:
                list_id.append(reference_no)
                faq_object = list_obj(db, reference_no)
                if not faq_object:
                    raise HTTPException(
                        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                        detail=f"Object with {reference_no} not found.",
                    )
                if record.active is not None:
                    faq_object.active = record.active
                if record.sort_order:
                    faq_object.sort_order = record.sort_order
                if record.question:
                    faq_object.question = record.question
                if record.answer:
                    faq_object.answer = record.answer

            if faq_object:
                save_obj(faq_object, db)

    remaining = [item for item in list_ids if item not in list_id]

    if remaining:
        for ref_id in remaining:
            faq = list_obj(db, ref_id)

            if not faq:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail=f"Object with {ref_id} not found.",
                )

            faq.deleted_at = datetime.datetime.utcnow()
            db.add(faq)
            db.commit()

    return get_obj(db)


def show(db: Session):
    return get_obj(db)
