import datetime
import json
import os

from app import models
from app.crud.base import get_mgc_response
from fastapi import HTTPException, status
from fastapi.responses import JSONResponse
from sqlalchemy.exc import SQLAlchemyError


def show():
    return JSONResponse(content={"vendor_id": os.environ.get('MGC_VENDOR_ID'), "secret_key": os.environ.get('MGC_SECRET'),
                                 "store_id_1": os.environ.get('STORE_ID'), "store_id_2": os.environ.get('STORE_ID')})


def check_unique(ip, db):
    ip_obj = db.query(models.WhitelistIPs).filter(
        models.WhitelistIPs.whitelist_ip == ip)
    if ip_obj.first():
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"{ip} already exists.")


def whitelist(account_id, db):
    ip_obj = db.query(models.WhitelistIPs).filter(
        models.WhitelistIPs.account_id == account_id).all()
    return ip_obj


def create(account_id, ip, db):
    try:
        check_unique(ip, db)
        obj = models.WhitelistIPs(account_id=account_id, whitelist_ip=ip)
        db.add(obj)
        db.commit()
        db.refresh(obj)
        end_point = "/api/v1/currency/whitelist_ip"
        payload = json.dumps({"ip": ip})
        json.loads(get_mgc_response(
            "POST", end_point, payload))
        return obj
    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def destroy(account_id, ip, db):
    ip_obj = db.query(models.WhitelistIPs).filter(models.WhitelistIPs.account_id == account_id,
                                                  models.WhitelistIPs.whitelist_ip == ip).first()
    if not ip_obj:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Ip with the {ip} is not available")
    ip_obj.deleted_at = datetime.datetime.utcnow()
    db.add(ip_obj)
    db.commit()
    end_point = "/api/v1/currency/whitelist_ip"
    payload = json.dumps({"ip": ip})
    json.loads(get_mgc_response(
        "DELETE", end_point, payload))
    return "ip delete successfully"
