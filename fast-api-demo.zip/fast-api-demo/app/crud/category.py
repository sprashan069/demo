import datetime

from app import models, schemas
from app.crud.base import get_ref_no
from fastapi import HTTPException, status
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from . import map_instance


def check_unique(request, db: Session, id=None):
    category = db.query(models.Category).filter(
        models.Category.name == request.name)
    if category:
        if id:
            category = category.filter(
                models.Category.ref_id != id)
    if category.first():
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Category with name {request.name} already exists.")


def get_all(db: Session):
    categories = db.query(models.Category).order_by(
        models.Category.created_at.asc()).all()
    for category in categories:
        category.id = category.ref_id
    return categories


def create(request, db: Session):
    check_unique(request, db)
    ref_id = get_ref_no("CAT")
    new_category = models.Category(name=request.name, ref_id=str(ref_id))
    try:
        db.add(new_category)
        db.commit()
        db.refresh(new_category)
        new_category.id = new_category.ref_id
        return new_category

    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def destroy(id: str, db: Session):
    category = db.query(models.Category).filter(
        models.Category.ref_id == id)

    record = category.first()

    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"category with id {id} not found")

    product = db.query(models.Product).filter(
        models.Product.category_id == id).first()
    if product:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Product allocated with this category id")

    category.update({'deleted_at': datetime.datetime.utcnow()})
    sub_categories = db.query(models.SubCategory).filter(
        models.SubCategory.category_id == record.ref_id)
    if sub_categories:
        for sub_category in sub_categories.all():
            product = db.query(models.Product).filter(
                models.Product.sub_category_id == sub_category.ref_id).first()
            if product:
                raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                                    detail=f"Product allocated with {sub_category.ref_id} sub category id")
        sub_categories.update({'deleted_at': datetime.datetime.utcnow()})

    db.commit()


def update(id: str, request: schemas.UpdateCategory, db: Session):
    check_unique(request, db, id)
    category = db.query(models.Category).filter(
        models.Category.ref_id == id)
    record = category.first()

    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"category with id {id} not found")
    try:
        stored_account_model = schemas.Category(**record.__dict__)
        update_data = request.dict(exclude_unset=True)
        updated_item = stored_account_model.copy(update=update_data)
        updated_record = map_instance(record, updated_item)
        db.add(updated_record)
        db.commit()
        db.refresh(updated_record)
        updated_record.id = updated_record.ref_id
        return updated_record
    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def show(id: str, db: Session):
    category = db.query(models.Category).filter(
        models.Category.ref_id == id).first()
    if not category:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"category with the id {id} is not available")
    category.id = category.ref_id
    return category
