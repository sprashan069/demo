import datetime
import json
import os
import random
import string
import time

import barcode
import boto3
from app import email_send, models
from app.crud import convert_expiry_date, get_expiration_date
from app.crud.base import (get_checkout_response, get_mgc_response, get_ref_no,
                           not_available)
from barcode.writer import ImageWriter
from fastapi import HTTPException, status
from fastapi_mail import FastMail, MessageSchema
from sqlalchemy import func
from sqlalchemy.exc import SQLAlchemyError


def get_orders(account_id, db):
    query = db.query(
        models.Order.created_at, models.Order.ref_id, models.Order.status, models.Order.quantity, models.Order.amount, models.Order.account_id, models.Order.total, models.Order.product_id, models.Order.style_id, models.Order.language, models.OrderDeliveryDetail.sender_name, models.OrderDeliveryDetail.recipient_email, models.OrderDeliveryDetail.phone_number, models.OrderDeliveryDetail.recipient_name, models.OrderDeliveryDetail.message, models.OrderDeliveryDetail.delivery_timestamp, models.OrderDeliveryDetail.delivery_mode, models.OrderDeliveryDetail.buy_for_self, models.Order.markup_rate, models.Order.payment_amount, models.Order.payment_currency
    )
    join_query = query.join(models.OrderDeliveryDetail, models.OrderDeliveryDetail.order_id ==
                            models.Order.ref_id, isouter=True).filter(models.Order.account_id == account_id)

    return join_query


def get_object(order, db):
    obj = {
        'createdAt': order.created_at,
        'orderId': order.ref_id,
        'orderStatus': order.status,
        'quantity': order.quantity,
        'amount': order.amount,
        'orderTotal': order.total,
        'markupRate': order.markup_rate,
        'paymentAmount': order.payment_amount,
        'paymentCurrency': order.payment_currency,
        'styleId': order.style_id,
        'name': order.sender_name,
        'language': order.language,
        'recipientName': order.recipient_name,
        'recipientEmail': order.recipient_email,
        'phoneNumber': order.phone_number,
        'message': order.message,
        'deliveryDate': order.delivery_timestamp,
        'deliveryMode': order.delivery_mode,
        'buyingForSelf': order.buy_for_self,
    }
    product = db.query(models.Product).filter(
        models.Product.ref_id == order.product_id).first()
    if product:
        obj['product'] = product

        currency = db.query(models.Currency).filter(
            models.Currency.ref_id == product.currency_id).first()
        if currency:
            obj['currency'] = currency

    order_detail = db.query(models.OrderDetail).filter(
        models.OrderDetail.order_id == order.ref_id, models.OrderDetail.order_detail_status == "CANCELED").first()
    merit_details = db.query(models.MeritOrderDetail).filter(
        models.MeritOrderDetail.order_id == order.ref_id).first()
    payment_details = db.query(models.OrderPaymentDetail).filter(
        models.OrderPaymentDetail.order_id == order.ref_id).order_by(models.OrderPaymentDetail.id.desc()).first()

    if payment_details:
        obj['error_message'] = f"Payment Error : {payment_details.error_message}" if (
            payment_details.error_message and order.status.name != "FULFILLED") else None
        obj['customer_id'] = payment_details.customer_id if payment_details.customer_id else None
    if merit_details:
        obj['error_message'] = f"MGC Error : {merit_details.error_message}" if (
            merit_details.error_message and order.status.name != "FULFILLED") else None
        merit_card = db.query(models.MeritGiftcard).filter(
            models.MeritGiftcard.merit_order_detail_id == merit_details.ref_id).first()
        if merit_card:
            obj['expirationDate'] = merit_card.expiration_date if merit_card.expiration_date else None
    if order_detail:
        obj['error_message'] = f"Canceled : {order_detail.error_message}" if (
            order_detail.error_message and order.status.name != "FULFILLED") else None
    return obj


def get_order_detail(order_id, account_id, db):
    orders = get_orders(account_id, db)
    order = orders.filter(models.Order.ref_id == order_id).first()
    if not order:
        raise HTTPException(status.HTTP_404_NOT_FOUND,
                            detail="Order not found")
    obj = {
        'order': get_object(order, db)
    }
    return obj


def save_obj(obj, db):
    try:
        db.add(obj)
        db.commit()
        db.refresh(obj)
        return obj
    except SQLAlchemyError as e:
        error = str(e.__dict__["orig"])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def index(account_id, db, skip, limit, fromDate, toDate):
    orders = get_orders(account_id, db).order_by(
        models.Order.created_at.desc())
    if toDate:
        orders = orders.filter(func.DATE(models.Order.created_at)
                               <= datetime.datetime.strptime(toDate, "%d/%m/%Y").date())
    if fromDate:
        orders = orders.filter(func.DATE(models.Order.created_at) >=
                               datetime.datetime.strptime(fromDate, "%d/%m/%Y").date())
    orders = orders.all()
    mappings = []
    for order in orders:
        d = get_object(order, db)
        mappings.append(d)
    records = mappings[skip: skip + limit]
    obj = {
        'data': {
            'orders': records
        }, 'total': len(records)
    }
    return obj


def create(order, account_id, db):
    not_available(models.Style,
                  order.style_id, "Style", db)
    ref_id = get_ref_no("ODR")

    error = []

    product = db.query(models.Product).filter(
        models.Product.ref_id == order.product_id).first()
    if not product:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Product not available")

    if order.amount < product.min_value or order.amount > product.max_value:
        error.append(
            f"Denomination should be in range between {product.min_value} and {product.max_value}")

    if order.quantity or order.quantity == 0:
        if order.quantity not in range(1, 5):
            error.append("Quantity should be in range between 1 and 4")
    else:
        order.quantity = 1

    language = order.language
    if not language:
        language = "en"
    else:
        if not language in ['en', 'ar']:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Language should be en or ar")

    if (order.delivery_mode == "BOTH") and (not order.phone_number or order.recipient_email):
        error.append("Phone number or email not found")
    elif (order.delivery_mode == "SMS") and (not order.phone_number):
        error.append("Phone number not found")
    elif (order.delivery_mode == "EMAIL") and (not order.recipient_email):
        error.append("Email not found")

    if order.buy_for_self == False:
        if not order.recipient_name:
            error.append("Recipient name not found")
        if not order.message:
            error.append("Message not found")
        if not order.delivery_timestamp:
            error.append("Delivery date not found")

    if error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=', '.join(error))

    new_order = models.Order(
        account_id=account_id,
        ref_id=str(ref_id),
        product_id=order.product_id,
        status="PENDING",
        quantity=order.quantity,
        language=language,
        amount=order.amount,
        total=order.quantity * order.amount,
        style_id=order.style_id
    )
    db.add(new_order)

    new_order_detail = models.OrderDetail(
        order_id=new_order.ref_id,
        order_detail_status="PENDING"
    )
    db.add(new_order_detail)

    delivery_detail = models.OrderDeliveryDetail(
        order_id=new_order.ref_id,
        sender_name=order.sender_name,
        recipient_email=order.recipient_email,
        phone_number=order.phone_number,
        buy_for_self=order.buy_for_self,
        delivery_mode=order.delivery_mode,
        recipient_name=order.recipient_name,
        message=order.message,
        delivery_timestamp=order.delivery_timestamp
    )
    db.add(delivery_detail)
    db.commit()
    get_order = get_order_detail(new_order.ref_id, account_id, db)
    return get_order


async def fulfill_order(order, order_obj, order_id, account_id, db):
    product_id = order.product.mgc_product_id
    quantity = order.quantity
    amount = order.amount
    order_reference_id = account_id + str(int(time.time())) + "".join(random.choices(
        (string.ascii_letters).upper(), k=4))
    account = db.query(models.Account).filter(
        models.Account.id == account_id).first()
    partner_name = account.domain if account else "Test"
    product = db.query(models.Product).filter(
        models.Product.ref_id == order.product.ref_id).first()
    vendor_id = os.environ.get('MGC_VENDOR_ID')

    payload = json.dumps({
        "giftcard": {
            "quantity": quantity,
            "denomination": amount,
            "campaign_id": product_id,
            "vendor_id": vendor_id,
            "request_id": order_reference_id,
            "partner_name": partner_name,
            "card_supplier": os.environ.get('MGC_SUPPLIER'),
            "card_expiry": get_expiration_date(datetime.date.today(), product.expiration_period).strftime("%d-%m-%Y")}})
    end_point = "/api/v1/currency/giftcards"

    error_message = "Something went wrong. Please try again later or contact Administrator."
    create_response = json.loads(get_mgc_response(
        "POST", end_point, payload))
    if create_response["code"] is status.HTTP_200_OK:
        payload = ""
        batch_id = create_response["data"]["giftcard"]["batch_id"]
        end_point = f"/api/v1/currency/giftcards?vendor_id={vendor_id}&batch_id={batch_id}"

        get_response = json.loads(get_mgc_response(
            "GET", end_point, payload))
        if get_response["code"] is status.HTTP_200_OK:
            giftcards = get_response["data"]["giftcards"]
            new_merit_order_detail = models.MeritOrderDetail(
                ref_id=str(get_ref_no("MOD")),
                order_id=order_id,
                order_reference_id=order_reference_id,
                batch_id=batch_id
            )
            db.add(new_merit_order_detail)

            new_order_detail = models.OrderDetail(
                order_id=order_id,
                order_detail_status="FULFILLED",
            )
            db.add(new_order_detail)

            for giftcard in giftcards:
                giftcard_pin = giftcard["giftcard_pin"] if 'giftcard_pin' in giftcard else None
                new_merit_giftcard = models.MeritGiftcard(
                    ref_id=str(get_ref_no("MGC")),
                    merit_order_detail_id=new_merit_order_detail.ref_id,
                    giftcard_number=giftcard["giftcard_number"],
                    card_id=giftcard["card_id"],
                    amount=giftcard["original_value"],
                    giftcard_pin=giftcard_pin,
                    product_id=giftcard["campaign_id"],
                    expiration_date=giftcard["expiration_date"],
                    currency=giftcard["currency"]
                )
                db.add(new_merit_giftcard)
                await send_mail(order_id, account_id, giftcard["giftcard_number"], giftcard["expiration_date"], db)
            order_obj.update({'status': "FULFILLED"})
            db.commit()
        elif create_response["message"]:
            new_merit_order_detail = models.MeritOrderDetail(
                ref_id=str(get_ref_no("MOD")),
                order_id=order_id,
                order_reference_id=order_reference_id,
                error_message=create_response["message"]
            )
            save_obj(new_merit_order_detail, db)
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=error_message)
        else:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=error_message)
    elif create_response["message"]:
        new_merit_order_detail = models.MeritOrderDetail(
            ref_id=str(get_ref_no("MOD")),
            order_id=order_id,
            order_reference_id=order_reference_id,
            error_message=create_response["message"]
        )
        save_obj(new_merit_order_detail, db)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=error_message)
    else:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=error_message)

    get_order = get_order_detail(
        order_id, account_id, db)
    return get_order


async def order_payment(order_id, order_payment, account_id, db):
    order_obj = db.query(models.Order).filter(
        models.Order.ref_id == order_id)
    order = order_obj.first()
    if not order:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"Order not available")
    get_order = get_order_detail(order_id, account_id, db)
    if order.status.name != "PENDING":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail='Order must be PENDING')

    error = []
    if order_payment.payment_success is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Payment success not found")
    if order_payment.payment_success is True:
        if not order_payment.payment_status:
            error.append("Payment status not found")
        if not order_payment.payment_id:
            error.append("Payment Id not found")
        if not order_payment.customer_id:
            error.append("Payment Customer id not found")

        if error:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, detail=', '.join(error))

        try:
            json.loads(
                get_checkout_response(order_payment.payment_id))
            # payment_currency = get_response["currency"]
            # payment_amount = get_response["amount"]
            # order_currency = order.product.currency.code
            # order_amount = order.total
        except:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid payment_id")

        # try:
        #     if payment_currency != order_currency:
        #         get_cr_response = currency_rates.show(
        #             order_currency, account_id, db)

        #         markups = get_cr_response["markups"]
        #         markup = markups[order_currency] if order_currency in markups else 2
        #         base_rate = get_cr_response["rates"][order_currency]
        #         markup_amount = ((order_amount * markup) / 100)
        #         total_order_amt = (order_amount * base_rate) + markup_amount

        #         go_ahead = (total_order_amt == payment_amount)
        #     else:
        #         markup = 0
        #         go_ahead = (payment_amount == order_amount)

        #     order_obj.update({'markup_rate': markup, 'payment_amount': payment_amount,
        #                       'payment_currency': payment_currency})
        #     db.commit()

        # except:
        #     raise HTTPException(
        #         status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Something went wrong. Please try again later or contact Administrator.")

        go_ahead = True
        if go_ahead:
            payment_detail = models.OrderPaymentDetail(
                order_id=order_id,
                ref_id=str(get_ref_no("OPD")),
                payment_id=order_payment.payment_id,
                customer_id=order_payment.customer_id,
                payment_status=order_payment.payment_status,
                payment_success=order_payment.payment_success
            )
            save_obj(payment_detail, db)

            new_order_detail = models.OrderDetail(
                order_id=order_id,
                order_detail_status="APPROVED"
            )
            save_obj(new_order_detail, db)

            order_obj.update({'status': "APPROVED"})
            db.commit()

            return await fulfill_order(order, order_obj, order_id, account_id, db)
        else:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail='Invalid Payment amount')
    else:
        payment_detail = models.OrderPaymentDetail(
            order_id=order_id,
            ref_id=str(get_ref_no("OPD")),
            payment_status=order_payment.payment_status,
            error_message=order_payment.error_message
        )
        db.add(payment_detail)

        new_order_detail = models.OrderDetail(
            order_id=order_id,
            order_detail_status="FAILED"
        )
        db.add(new_order_detail)

        order_obj.update({'status': "FAILED"})
        db.commit()
    return get_order


def reprocess_order(order_id, account_id, db):
    order_obj = db.query(models.Order).filter(
        models.Order.ref_id == order_id)
    order = order_obj.first()
    if not order:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"Invalid Order")

    order_details = db.query(models.OrderDetail).filter(
        models.OrderDetail.order_id == order_id, models.OrderDetail.order_detail_status.in_(['FULFILLED', 'CANCELED', 'FAILED'])).all()
    if order_details:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"Order is already {order_details[-1].order_detail_status.name}, It can not be re-process")

    if not order.status.name == "APPROVED":
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"Only approved orders can be re-process!!")

    return fulfill_order(order, order_obj, order_id, account_id, db)


def show(order_id, account_id, db):
    return get_order_detail(order_id, account_id, db)


def cancel_order(order_id, account_id, reason_obj, db):
    order_obj = db.query(models.Order).filter(
        models.Order.ref_id == order_id, models.Order.account_id == account_id)
    order = order_obj.first()
    if not order:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"Invalid Order ID")

    order_details = db.query(models.OrderDetail).filter(
        models.OrderDetail.order_id == order_id, models.OrderDetail.order_detail_status.in_(['APPROVED', 'FULFILLED', 'CANCELED', 'FAILED'])).all()
    if order_details:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"Order is already {order_details[-1].order_detail_status.name}, It can not be cancel")

    new_order_detail = models.OrderDetail(
        order_id=order_id,
        order_detail_status="CANCELED",
        error_message=reason_obj.reason
    )
    db.add(new_order_detail)

    order_obj.update({'status': "CANCELED"})
    db.commit()


async def send_mail(order_id, account_id, giftcard_number, expiration_date, db):
    order = get_order_detail(order_id, account_id, db)
    product = db.query(models.Product).filter(
        models.Product.ref_id == order['order']['product'].ref_id).first()
    currency = db.query(models.Currency).filter(
        models.Currency.ref_id == order['order']['currency'].ref_id).first()
    style = db.query(models.Style).filter(
        models.Style.ref_id == order['order']['styleId']).first()
    header = db.query(models.VendorSetting).filter(
        models.VendorSetting.account_id == account_id).first()

    s3 = boto3.client('s3', )
    temp_dir = os.path.join(os.getcwd(), 'tmp')
    if not os.path.exists(temp_dir):
        os.mkdir(temp_dir)
    options = {
        'module_height': 9.0,
        'write_text': False
    }
    code = barcode.get('code128', giftcard_number, writer=ImageWriter())
    barcode_img = code.save('tmp/code128_barcode', options)
    file_name = str(round(time.time() * 1000)) + "_" + 'code128_barcode.png'
    s3_bucket_name = os.environ.get('AWS_S3_BUCKET')
    s3.upload_file(barcode_img, s3_bucket_name, file_name,
                   ExtraArgs={'ACL': 'public-read'})
    os.remove(barcode_img)

    bucket_location = boto3.client(
        's3').get_bucket_location(Bucket=s3_bucket_name)
    object_url = "https://s3-{0}.amazonaws.com/{1}/{2}".format(
        bucket_location['LocationConstraint'], s3_bucket_name, file_name)

    context = {
        "order": order,
        "product": product,
        "currency": currency,
        "barcode": object_url,
        "giftcard_number": giftcard_number,
        "header_logo": header.header_logo,
        "expiration_date": convert_expiry_date(expiration_date),
        "banner_image": style.image
    }
    if order:
        fm = FastMail(email_send)
        recipients = order['order']['recipientEmail'].split(',')
        template_name = "email_template.html"
        subject = "You have received your " + currency.code + \
            " " + str(int(order['order']['amount'])) + " gift card"
        if order['order']['language'] == "ar":
            context['banner_image'] = style.image_ar
            template_name = "arabic-email-template.html"
            subject = "You have received your " + currency.code + \
                " " + str(int(order['order']['amount'])) + " gift card"
        message = MessageSchema(
            subject=subject,
            recipients=recipients,
            body=context)
        await fm.send_message(message, template_name)


async def resend_email(order_id, account_id, db):
    order_obj = db.query(models.Order).filter(
        models.Order.ref_id == order_id)
    order = order_obj.first()
    if not order_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"Invalid Order")

    if not order.status.name == "FULFILLED":
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"Order is not fulfilled yet!!")

    order_detail = db.query(models.MeritOrderDetail).filter(
        models.MeritOrderDetail.order_id == order_id).order_by(models.MeritOrderDetail.id.desc()).first()
    giftcards = db.query(models.MeritGiftcard).filter(
        models.MeritGiftcard.merit_order_detail_id == order_detail.ref_id).all()
    for giftcard in giftcards:
        await send_mail(order_id, account_id, giftcard.giftcard_number, giftcard.expiration_date, db)


def order_status(account_id, db):
    orders = db.query(models.Order).filter(
        models.Order.account_id == account_id)
    pending_orders = orders.filter(models.Order.status == "PENDING")
    approved_orders = orders.filter(models.Order.status == "APPROVED")
    fulfilled_orders = orders.filter(models.Order.status == "FULFILLED")
    failed_orders = orders.filter(models.Order.status == "FAILED")
    canceled_orders = orders.filter(models.Order.status == "CANCELED")
    order = {
        "total_orders": orders.count(),
        "pending_orders": pending_orders.count(),
        "approved_orders": approved_orders.count(),
        "fulfilled_orders": fulfilled_orders.count(),
        "canceled_orders": canceled_orders.count(),
        "failed_orders": failed_orders.count()
    }
    return order
