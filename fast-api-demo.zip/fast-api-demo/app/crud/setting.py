import datetime

from app import models, upload_image
from app.crud import parse_to_dict_vals
from app.crud.base import get_ref_no, verify_active
from fastapi import HTTPException, status
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session


def get_obj(db):
    footer = db.query(models.Setting).first()
    obj = footer.__dict__ if footer else {}
    obj["contact_info"] = []
    for contact in db.query(models.CompanyContact).order_by(
            models.CompanyContact.created_at.asc()).all():
        obj["contact_info"].append(contact.__dict__)
        contact.id = contact.ref_id
    obj["footer_menu"] = []
    for menu in db.query(models.FooterMenu).order_by(
            models.FooterMenu.created_at.asc()).all():
        obj["footer_menu"].append(menu.__dict__)
        menu.id = menu.ref_id
    obj["social"] = []
    for social in db.query(models.SocialMedia).order_by(
            models.SocialMedia.created_at.asc()).all():
        obj["social"].append(social.__dict__)
        social.id = social.ref_id
    return obj


def save_obj(new_obj, db):
    try:
        db.add(new_obj)
        db.commit()
        db.refresh(new_obj)

    except SQLAlchemyError as e:
        error = str(e.__dict__["orig"])
        return error


def get_object(id, model, db):
    return db.query(model).filter(model.ref_id == id).first()


def show(db: Session):
    return get_obj(db)


def update(header_title, header_logo, footer_logo, copy_right, db: Session):
    settings = db.query(models.Setting).all()
    h_logo = upload_image(header_logo)
    f_logo = upload_image(footer_logo)

    if not settings:
        header = models.Setting(
            header_title=header_title,
            header_logo=h_logo,
            footer_logo=f_logo,
            copy_right=copy_right,
        )
    else:
        header = settings[0]
        if header_title or header_title == "":
            header.header_title = header_title
        if header_logo:
            header.header_logo = h_logo
        if footer_logo:
            header.footer_logo = f_logo
        if copy_right or copy_right == "":
            header.copy_right = copy_right

    try:
        db.add(header)
        db.commit()
        db.refresh(header)
        obj = get_obj(db)
        return obj

    except SQLAlchemyError as e:
        error = str(e.__dict__["orig"])
        return error


def update_contact(request, db: Session):
    records = request.contact_info
    list_ids = []
    list_id = []
    for contact in db.query(models.CompanyContact).all():
        list_ids.append(contact.ref_id)
    if records:
        for record in records:
            reference_no = record.id
            if not reference_no:
                ref_id = get_ref_no("CON")
                contact_object = models.CompanyContact(
                    ref_id=str(ref_id),
                    active=record.active,
                    title=record.title,
                    description=record.description,
                )
            else:
                list_id.append(reference_no)
                contact_object = get_object(
                    reference_no, models.CompanyContact, db)
                if not contact_object:
                    raise HTTPException(
                        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                        detail=f"Object with {reference_no} not found.",
                    )
                if record.active is not None:
                    contact_object.active = record.active
                if record.title:
                    contact_object.title = record.title
                if record.description:
                    contact_object.description = record.description

            if contact_object:
                save_obj(contact_object, db)

    remaining = [item for item in list_ids if item not in list_id]
    if remaining:
        for ref_id in remaining:
            contact = get_object(ref_id, models.CompanyContact, db)

            if not contact:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail=f"Object with {ref_id} not found.",
                )

            contact.deleted_at = datetime.datetime.utcnow()
            db.add(contact)
            db.commit()
    return get_obj(db)


def update_footer(request, db: Session):
    records = request.footer_menu
    list_ids = []
    list_id = []
    for footer in db.query(models.FooterMenu).all():
        list_ids.append(footer.ref_id)
    if records:
        for record in records:
            reference_no = record.id
            if not reference_no:
                ref_id = get_ref_no("FTR")
                footer_object = models.FooterMenu(
                    ref_id=str(ref_id),
                    active=record.active,
                    title=record.title,
                    link=record.link,
                )
            else:
                list_id.append(reference_no)
                footer_object = get_object(reference_no, models.FooterMenu, db)
                if not footer_object:
                    raise HTTPException(
                        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                        detail=f"Object with {reference_no} not found.",
                    )
                if record.active is not None:
                    footer_object.active = record.active
                if record.title:
                    footer_object.title = record.title
                if record.link:
                    footer_object.link = record.link

            if footer_object:
                save_obj(footer_object, db)

    remaining = [item for item in list_ids if item not in list_id]
    if remaining:
        for ref_id in remaining:
            footer = get_object(ref_id, models.FooterMenu, db)

            if not footer:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail=f"Object with {ref_id} not found.",
                )

            footer.deleted_at = datetime.datetime.utcnow()
            db.add(footer)
            db.commit()

    return get_obj(db)


def update_social_media_links(request, db: Session):
    request_dict = parse_to_dict_vals(request)
    if not request_dict:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Parameter missing!!",
        )
    try:
        links = request_dict['links']
    except:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Invalid Parameter!!",
        )

    list_ids = []
    list_id = []
    for media in db.query(models.SocialMedia).all():
        list_ids.append(media.ref_id)

    for key in links:
        obj = links[key]
        reference_no = obj['id'] if ('id' in obj) else None
        link = obj['link'] if ('link' in obj) else None
        icon = upload_image(obj['icon']) if ('icon' in obj) else None
        active = verify_active(obj['active']) if ('active' in obj) else None

        if not reference_no:

            ref_id = get_ref_no("MDA")
            media_object = models.SocialMedia(
                ref_id=str(ref_id),
                active=active,
                icon=icon,
                link=link,
            )
        else:

            list_id.append(reference_no)
            media_object = get_object(reference_no, models.SocialMedia, db)
            if not media_object:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail=f"Object with {reference_no} not found.",
                )
            if active is not None:
                media_object.active = active
            if icon:
                media_object.icon = icon
            if link:
                media_object.link = link

        if media_object:
            obj = save_obj(media_object, db)

    remaining = [item for item in list_ids if item not in list_id]
    if remaining:
        for ref_id in remaining:
            media = get_object(ref_id, models.SocialMedia, db)

            if not media:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail=f"Object with {ref_id} not found.",
                )

            media.deleted_at = datetime.datetime.utcnow()
            db.add(media)
            db.commit()

    return get_obj(db)
