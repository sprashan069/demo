import datetime

from app import models, schemas
from app.crud.base import get_ref_no, not_available
from fastapi import HTTPException, status
from sqlalchemy import or_
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session


def check_unique(request, db: Session, id=None):
    regions = db.query(models.Region).filter(or_(models.Region.name == request.name,
                                                 models.Region.subregion_name == request.subregion_name))
    if regions:
        if id:
            regions = regions.filter(models.Region.ref_id != id)
    if regions.first():
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Region with name {request.name} or subregion_name {request.subregion_name}  already exists.")


def get_all(country_id, db: Session):
    regions = db.query(models.Region)
    exists = db.query(models.Country).filter_by(
        ref_id=country_id).first() is not None
    if not exists and country_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"Country with id {country_id} does not exists.")
    if country_id:
        regions = regions.filter(
            models.Region.country_id == country_id)
    regions = regions.order_by(
        models.Region.created_at.asc()).all()
    for region in regions:
        region.id = region.ref_id
        region.country.id = region.country.ref_id
    return regions


def create(request, db: Session):
    check_unique(request, db)
    not_available(models.Country, request.country_id, "Country", db)
    ref_id = get_ref_no("RGN")
    new_region = models.Region(name=request.name, subregion_name=request.subregion_name,
                               country_id=request.country_id, ref_id=str(ref_id))
    try:
        db.add(new_region)
        db.commit()
        db.refresh(new_region)
        new_region.id = new_region.ref_id
        new_region.country.id = new_region.country.ref_id
        return new_region

    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def destroy(id: str, db: Session):
    region = db.query(models.Region).filter(
        models.Region.ref_id == id)

    if not region.first():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"region with id {id} not found")

    product = db.query(models.Product).filter(
        models.Product.region_id == id).first()
    if product:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Product allocated with this region id")

    region.update({'deleted_at': datetime.datetime.utcnow()})
    db.commit()


def update(id: str, request: schemas.UpdateRegion, db: Session):
    check_unique(request, db, id)
    region = db.query(models.Region).filter(
        models.Region.ref_id == id)
    record = region.first()

    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"region with id {id} not found")
    try:
        if request.name or request.name == "":
            record.name = request.name
        if request.subregion_name or request.subregion_name == "":
            record.subregion_name = request.subregion_name
        if request.country_id:
            not_available(models.Country, request.country_id, "Country", db)
            record.country_id = request.country_id

        db.add(record)
        db.commit()
        db.refresh(record)
        record.id = record.ref_id
        record.country.id = record.country.ref_id
        return record
    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def show(id: str, db: Session):
    region = db.query(models.Region).filter(
        models.Region.ref_id == id).first()
    if not region:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"region with the id {id} is not available")
    region.id = region.ref_id
    region.country.id = region.country.ref_id
    return region
