from app import models
from app.crud.base import get_ref_no
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session


def get_obj(db):
    obj = db.query(models.Term).first()
    return {} if not obj else obj


def save_obj(new_obj, db):
    try:
        db.add(new_obj)
        db.commit()
        db.refresh(new_obj)
        obj = get_obj(db)
        return obj

    except SQLAlchemyError as e:
        error = str(e.__dict__["orig"])
        return error


def update(request, db: Session):
    objects = db.query(models.Term).all()

    if not objects:
        ref_id = get_ref_no("TER")
        obj = models.Term(
            ref_id=str(ref_id),
            active=request.active,
            terms_text=request.terms_text,
            link=request.link
        )
    else:
        obj = objects[0]
        if request.active is not None:
            obj.active = request.active
        if request.terms_text:
            obj.terms_text = request.terms_text
        if request.link:
            obj.link = request.link

    record = save_obj(obj, db)
    return record


def show(db: Session):
    obj = get_obj(db)
    return obj
