from app import models
from app.crud.base import get_first_obj, get_ref_no
from fastapi import HTTPException, status
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session


def get_obj(db):
    obj = {}
    obj["contacts"] = []
    records = db.query(models.Contact).all()
    for record in records:
        record.id = record.ref_id
        obj["contacts"].append(record.__dict__)
    return obj


def create(request, db: Session):
    ref_id = get_ref_no("CON")
    contact = models.Contact(
        name=request.name, email=request.email, role=request.role, message=request.message, ref_id=str(ref_id))
    try:
        db.add(contact)
        db.commit()
        db.refresh(contact)
        contact.id = contact.ref_id
        return contact
    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def index(id, db: Session):
    record = get_first_obj(db, models.Contact, id)
    record.id = record.ref_id
    return record


def show(db):
    return get_obj(db)
