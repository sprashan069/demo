import datetime

from app import models, upload_image
from app.crud.base import get_ref_no
from fastapi import HTTPException, status
from sqlalchemy.orm import Session


def get(db):
    companies = db.query(models.CompanyDetail).order_by(
        models.CompanyDetail.created_at.asc()).all()
    for company in companies:
        company.id = company.ref_id
    return companies


def show(db: Session):
    return get(db)


def add_company_detail(title, sub_title, description, image, active, db: Session):
    ref_id = get_ref_no("COM")
    obj = models.CompanyDetail(title=title,
                               sub_title=sub_title,
                               description=description,
                               active=active,
                               image=upload_image(image),
                               ref_id=str(ref_id))

    db.add(obj)
    db.commit()
    db.refresh(obj)
    obj.id = obj.ref_id
    return obj.__dict__


def update_company_detail(id, title, sub_title, description, image, active, db: Session):
    obj = db.query(models.CompanyDetail).filter(
        models.CompanyDetail.ref_id == id).first()

    if not obj:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Object with that id not found.")

    if title:
        obj.title = title
    if sub_title or sub_title == "":
        obj.sub_title = sub_title
    if description:
        obj.description = description
    if active is not None:
        obj.active = active
    if image:
        obj.image = upload_image(image)

    db.add(obj)
    db.commit()
    db.refresh(obj)
    obj.id = obj.ref_id
    return obj.__dict__


def delete_company_detail(id: str, db: Session):
    obj = db.query(models.CompanyDetail).filter(
        models.CompanyDetail.ref_id == id).first()

    if not obj:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Object with that id not found.")

    obj.deleted_at = datetime.datetime.utcnow()
    db.add(obj)
    db.commit()
