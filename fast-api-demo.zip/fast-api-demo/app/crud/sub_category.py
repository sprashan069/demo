import datetime

from app import models, schemas
from app.crud.base import get_ref_no, not_available
from fastapi import HTTPException, status
from sqlalchemy import or_
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from . import map_instance


def check_unique(request, db: Session, id=None):
    sub_category = db.query(models.SubCategory).filter(
        or_(models.SubCategory.name == request.name))
    if sub_category:
        if id:
            sub_category = sub_category.filter(
                models.SubCategory.ref_id != id)
    if sub_category.first():
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Sub category with name {request.name} already exists.")


def get_all(category_id, db: Session):
    sub_categories = db.query(models.SubCategory)
    exists = db.query(models.Category).filter_by(
        ref_id=category_id).first() is not None
    if not exists and category_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"Category with id {category_id} does not exists.")
    if category_id:
        sub_categories = sub_categories.filter(
            models.SubCategory.category_id == category_id)
    sub_categories = sub_categories.order_by(
        models.SubCategory.created_at.asc()).all()
    for sub_category in sub_categories:
        sub_category.id = sub_category.ref_id
    return sub_categories


def create(request, db: Session):
    check_unique(request, db)
    not_available(models.Category, request.category_id, "Category", db)
    ref_id = get_ref_no("SCT")
    new_sub_category = models.SubCategory(
        name=request.name, category_id=request.category_id, ref_id=str(ref_id))
    try:
        db.add(new_sub_category)
        db.commit()
        db.refresh(new_sub_category)
        new_sub_category.id = new_sub_category.ref_id
        return new_sub_category

    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def destroy(id: str, db: Session):
    sub_category = db.query(models.SubCategory).filter(
        models.SubCategory.ref_id == id)

    if not sub_category.first():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"sub_category with id {id} not found")

    product = db.query(models.Product).filter(
        models.Product.sub_category_id == id).first()
    if product:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Product allocated with this sub category id")

    sub_category.update({'deleted_at': datetime.datetime.utcnow()})
    db.commit()


def update(id: str, request: schemas.UpdateSubCategory, db: Session):
    check_unique(request, db, id)
    sub_category = db.query(models.SubCategory).filter(
        models.SubCategory.ref_id == id)
    record = sub_category.first()

    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"sub_category with id {id} not found")
    try:
        if request.category_id:
            not_available(models.Category, request.category_id, "Category", db)
        stored_account_model = schemas.SubCategory(**record.__dict__)
        update_data = request.dict(exclude_unset=True)
        updated_item = stored_account_model.copy(update=update_data)
        updated_record = map_instance(record, updated_item)
        db.add(updated_record)
        db.commit()
        db.refresh(updated_record)
        updated_record.id = updated_record.ref_id
        return updated_record
    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def show(id: str, db: Session):
    sub_category = db.query(models.SubCategory).filter(
        models.SubCategory.ref_id == id).first()
    if not sub_category:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"sub_category with the id {id} is not available")
    sub_category.id = sub_category.ref_id
    return sub_category
