import datetime

from app import models
from app.db import session
from app.db.session import SessionLocal
from fastapi import APIRouter, HTTPException, status
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session
from worker import app

router = APIRouter(
    prefix="/accounts",
    tags=['Accounts']
)

get_db = session.get_db


def save_obj(new_obj, db):
    try:
        db.add(new_obj)
        db.commit()
        db.refresh(new_obj)
        return new_obj

    except SQLAlchemyError as e:
        error = str(e.__dict__["orig"])
        return HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def get_all(db: Session):
    accounts = db.query(models.Account).all()
    return accounts


def save_data(currency, vat):
    db = SessionLocal()
    data = models.AccountVat(currency=currency, vat=vat)
    save_obj(data, db)


def get_account(id: str, db: Session):
    obj = db.query(models.Account).filter(models.Account.id == id).first()
    if not obj:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Object with {id} not found.",
        )
    return obj


def update(id: str, account_obj, db: Session):
    data = get_account(id, db)

    AED = account_obj.AED
    EUR = account_obj.EUR
    SAR = account_obj.SAR
    USD = account_obj.USD
    subscription_charge = account_obj.subscription_charge
    base_currency = account_obj.base_currency
    account_status = account_obj.account_status
    vat = account_obj.vat

    if data:
        if AED or AED == "":
            data.AED = AED
        if EUR or EUR == "":
            data.EUR = EUR
        if SAR or SAR == "":
            data.SAR = SAR
        if USD or USD == "":
            data.USD = USD
        if subscription_charge:
            data.subscription_charge = subscription_charge
        else:
            data.subscription_charge = 5
        if base_currency:
            data.base_currency = base_currency
            data.default_currency_selected = True
        if vat:
            data.vat = vat
    data.account_status = account_status

    record = save_obj(data, db)
    return record


@app.task
def account_status():
    db = SessionLocal()
    account_obj = db.query(models.Account).filter(
        models.Account.account_status == models.AccountStatus.ACTIVE.value)
    accounts = account_obj.all()
    for account in accounts:
        if not account.subscription_date and account.trial_end_at < datetime.datetime.now():
            account.account_status = models.AccountStatus.INACTIVE.value
            account.publish = False
            db.commit()
