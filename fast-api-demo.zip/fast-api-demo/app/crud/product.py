import datetime

from app import get_account_from_request, models, upload_image
from app.crud.base import get_ref_no, not_available
from fastapi import HTTPException, status
from sqlalchemy.exc import SQLAlchemyError


def get_product_list(db):
    return db.query(models.Product).order_by(
        models.Product.created_at.asc()).all()


def get_all(db):
    products = get_product_list(db)
    for product in products:
        product.id = product.ref_id
        product.country.id = product.country_id
        product.region.id = product.region_id
        product.brand.id = product.brand_id
        product.category.id = product.category_id
        product.sub_category.id = product.sub_category_id
        if product.style:
            product.style.id = product.style_id

        currency = db.query(models.Currency).filter(
            models.Currency.ref_id == product.currency_id).first()
        if currency:
            product.currency_code = currency.code

        account = db.query(models.Account).filter(
            models.Account.id == product.account_id).first()
        if account:
            product.tenant = account.domain
    return products


def super_admin(db, is_default):
    products = db.query(models.Product).filter(models.Product.is_default == is_default).order_by(
        models.Product.created_at.asc()).all()

    for product in products:
        product.id = product.ref_id

        account = db.query(models.Account).filter(
            models.Account.id == product.account_id).first()
        product.tenant = account.domain if account else None

        country = db.query(models.Country).filter(
            models.Country.ref_id == product.country_id).first()
        product.country_name = country.name if country else None

        brand = db.query(models.Brand).filter(
            models.Brand.ref_id == product.brand_id).first()
        product.brand_name = brand.name if brand else None

        category = db.query(models.Category).filter(
            models.Category.ref_id == product.category_id).first()
        product.category_name = category.name if category else None

        sub_category = db.query(models.SubCategory).filter(
            models.SubCategory.ref_id == product.sub_category_id).first()
        product.sub_category_name = sub_category.name if sub_category else None

        currency = db.query(models.Currency).filter(
            models.Currency.ref_id == product.currency_id).first()
        product.currency_name = currency.name if currency else None

    return products


def super_admin_dropdown(db):
    products = get_product_list(db)
    for product in products:
        product.id = product.ref_id
    return products


def get_obj(ref_id, db):
    product = db.query(models.Product).filter(
        models.Product.ref_id == ref_id).first()
    if not product:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"Product with the id {ref_id} is not available")
    product.id = product.ref_id
    product.country.id = product.country_id
    product.region.id = product.region_id
    product.brand.id = product.brand_id
    product.category.id = product.category_id
    product.sub_category.id = product.sub_category_id
    if product.style:
        product.style.id = product.style_id

    currency = db.query(models.Currency).filter(
        models.Currency.ref_id == product.currency_id).first()
    if currency:
        product.currency_code = currency.code

    account = db.query(models.Account).filter(
        models.Account.id == product.account_id).first()
    if account:
        product.tenant = account.domain

    return product


def check_not_available(brand_id, country_id, region_id, currency_id, category_id, sub_category_id, db):
    not_available(models.Brand, brand_id, "Brand", db)
    not_available(models.Country, country_id, "Country", db)
    not_available(models.Region, region_id, "Region", db)
    not_available(models.Currency, currency_id, "Currency", db)
    not_available(models.Category, category_id, "Category", db)
    not_available(models.SubCategory, sub_category_id, "SubCategory", db)


def validate_expiration_period(expiration_period):
    if expiration_period not in range(0, 4):
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail="Invalid expiration period")


def validate_denomination(min_value, max_value, denominations):
    amount = denominations.replace(" ", "")
    amt_list = [float(item) for item in amount.split(",")]

    for amt in amt_list:
        if amt < min_value or amt > max_value:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                                detail="Denomination should be greater than from minimum value and less than from maximum value")
    return amount


def create(name, active, is_default, expiration_period, brand_id, country_id, region_id, currency_id, category_id, sub_category_id, style_id, style_image, product_image, description, description_ar, terms, terms_ar, how_to_redeem, how_to_redeem_ar, mgc_product_id, is_quantity, is_range, is_fix_amount, min_value, max_value, denominations, is_email, is_sms, request, db):
    try:
        account_id = get_account_from_request(request, db)
    except:
        account_id = None

    validate_expiration_period(expiration_period)
    denomination = validate_denomination(min_value, max_value, denominations)

    check_not_available(brand_id, country_id, region_id, currency_id,
                        category_id, sub_category_id, db)

    if style_id:
        not_available(models.Style, style_id, "Style", db)
    else:
        error = []
        if not style_image:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Style image not found")

        style_ref_id = get_ref_no("STY")
        admin_user_flag = not account_id

        new_style = models.Style(image=upload_image(style_image), active=True, custom=False, ref_id=str(
            style_ref_id), is_product=True, admin_user_flag=admin_user_flag)
        try:
            db.add(new_style)
            db.commit()
            db.refresh(new_style)
            style_id = new_style.ref_id

        except SQLAlchemyError as e:
            error = str(e.__dict__['orig'])
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)

    ref_id = get_ref_no("PRD")
    new_product = models.Product(name=name, active=active, is_default=is_default, ref_id=str(ref_id), expiration_period=expiration_period, brand_id=brand_id, country_id=country_id, region_id=region_id, currency_id=currency_id, category_id=category_id, sub_category_id=sub_category_id,
                                 style_id=style_id, product_image=upload_image(product_image), description=description, description_ar=description_ar, terms=terms, terms_ar=terms_ar, how_to_redeem=how_to_redeem, how_to_redeem_ar=how_to_redeem_ar, mgc_product_id=mgc_product_id, is_quantity=is_quantity, is_range=is_range, is_fix_amount=is_fix_amount, min_value=min_value, max_value=max_value, denominations=denomination, admin_denominations=denomination, is_email=is_email, is_sms=is_sms, account_id=account_id)

    try:
        db.add(new_product)
        db.commit()
        db.refresh(new_product)
        return get_obj(new_product.ref_id, db)

    except SQLAlchemyError as e:
        error = str(e.__dict__["orig"])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def destroy(id: str, db):
    product = db.query(models.Product).filter(
        models.Product.ref_id == id)

    record = product.first()
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"product with id {id} not found")

    product.update({'deleted_at': datetime.datetime.utcnow()})

    db.commit()


def update(id: str, name, active, is_default, expiration_period, brand_id, country_id, region_id, currency_id, category_id, sub_category_id, style_id, style_image, product_image, description, description_ar, terms, terms_ar, how_to_redeem, how_to_redeem_ar, mgc_product_id, is_quantity, is_range, is_fix_amount, min_value, max_value, denominations, admin_denominations, is_email, is_sms, db):
    product = db.query(models.Product).filter(
        models.Product.ref_id == id)
    record = product.first()

    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"product with id {id} not found")

    check_not_available(brand_id, country_id, region_id, currency_id,
                        category_id, sub_category_id, db)

    if name:
        record.name = name
    if active is not None:
        record.active = active
    if is_default is not None:
        record.is_default = is_default
    if expiration_period or expiration_period == 0:
        validate_expiration_period(expiration_period)
        record.expiration_period = expiration_period
    if brand_id:
        record.brand_id = brand_id
    if country_id:
        record.country_id = country_id
    if region_id:
        record.region_id = region_id
    if currency_id:
        record.currency_id = currency_id
    if category_id:
        record.category_id = category_id
    if sub_category_id:
        record.sub_category_id = sub_category_id
    if style_id:
        not_available(models.Style, style_id, "Style", db)
        record.style_id = style_id
    if style_image:
        error = []
        style_ref_id = get_ref_no("STY")

        new_style = models.Style(image=upload_image(style_image), active=True, custom=False, ref_id=str(
            style_ref_id), is_product=True, admin_user_flag=True)
        try:
            db.add(new_style)
            db.commit()
            db.refresh(new_style)
            record.style_id = new_style.ref_id

        except SQLAlchemyError as e:
            error = str(e.__dict__['orig'])
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)
    if product_image:
        record.product_image = upload_image(product_image)
    if description:
        record.description = description
    if description_ar:
        record.description_ar = description_ar
    if terms:
        record.terms = terms
    if terms_ar:
        record.terms_ar = terms_ar
    if how_to_redeem:
        record.how_to_redeem = how_to_redeem
    if how_to_redeem_ar:
        record.how_to_redeem_ar = how_to_redeem_ar
    if mgc_product_id:
        record.mgc_product_id = mgc_product_id
    if is_quantity is not None:
        record.is_quantity = is_quantity
    if is_range is not None:
        record.is_range = is_range
    if is_fix_amount is not None:
        record.is_fix_amount = is_fix_amount
    if min_value:
        record.min_value = min_value
    if max_value:
        record.max_value = max_value
    if denominations:
        denomination = validate_denomination(
            record.min_value, record.max_value, denominations)
        record.denominations = denomination
    if admin_denominations:
        admin_denomination = validate_denomination(
            record.min_value, record.max_value, admin_denominations)
        record.admin_denominations = admin_denomination
    if is_email is not None:
        record.is_email = is_email
    if is_sms is not None:
        record.is_sms = is_sms

    db.add(record)
    db.commit()
    db.refresh(record)
    return get_obj(record.ref_id, db)


def show(id: str, db):
    return get_obj(id, db)
