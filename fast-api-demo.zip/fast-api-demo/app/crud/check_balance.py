import json

from app import models
from app.crud.base import get_mgc_response
from fastapi import HTTPException, status


def get(account_id, giftcard_number, db):
    merit_giftcard_details = db.query(models.MeritGiftcard.created_at, models.MeritGiftcard.giftcard_number, models.MeritGiftcard.merit_order_detail_id, models.MeritOrderDetail.ref_id, models.MeritOrderDetail.order_id).join(models.MeritGiftcard, models.MeritGiftcard.giftcard_number == giftcard_number, isouter=True).filter(
        models.MeritOrderDetail.ref_id == models.MeritGiftcard.merit_order_detail_id).first()

    if not merit_giftcard_details:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"giftcard with this number {giftcard_number} is not available")

    product = db.query(models.Order.ref_id, models.Order.product_id, models.Product.ref_id, models.Product.name, models.Product.terms, models.Product.description, models.Product.how_to_redeem).join(models.Order, models.Order.ref_id == merit_giftcard_details.order_id).filter(
        models.Order.account_id == account_id).first()

    if not product:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail=f"Invalid giftcard number")

    end_point = f"/api/v1/currency/giftcards/balance_check?card_number={giftcard_number}"
    response = json.loads(get_mgc_response(
        "GET", end_point, ""))

    obj = {
        "remaining_value": response['data']['remaining_value'],
        "expiration_date": response['data']['expiry_date'],
        "activation_date": merit_giftcard_details.created_at.date(),
        "giftcard_image": response['data']['giftcard_image'],
        "currency": response['data']['giftcard_currency'],
        "original_value": response['data']['original_value'],
        "terms & conditons": product.terms,
        "description": product.description,
        "how_to_redeem": product.how_to_redeem,
    }
    return obj
