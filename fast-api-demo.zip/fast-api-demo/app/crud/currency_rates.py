import datetime
import http.client
import json
import os

from app import models
from app.db.session import SessionLocal
from fastapi import HTTPException, status
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session
from worker import app


def save_obj(obj, db):
    try:
        db.add(obj)
        db.commit()
        db.refresh(obj)
        return obj
    except SQLAlchemyError as e:
        error = str(e.__dict__["orig"])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def get_currency_response(request_type, end_point, payload):
    conn = http.client.HTTPSConnection(os.environ.get('FIXER_URL'))

    headers = {
        'Content_Type': 'application/json'
    }

    conn.request(request_type, end_point, payload, headers)
    res = conn.getresponse()
    data = res.read()
    return data.decode("utf-8")


def create_currency_rates(new_date, base):
    db = SessionLocal()
    currency = db.query(models.FixerCurrencyRate).filter(models.FixerCurrencyRate.date ==
                                                         new_date, models.FixerCurrencyRate.base_currency == base).first()
    if currency:
        return currency
    end_point = f'/api/{new_date}?access_key={os.environ.get("FIXER_API_KEY")}&base={base}'

    response = json.loads(get_currency_response(
        "GET", end_point, ""))
    if response['success'] == True:
        date_obj = response['date']
        rates = json.dumps(response['rates'])
        base = response['base']
        currency_rates = models.FixerCurrencyRate(
            date=date_obj, rates=rates, base_currency=base)
        return save_obj(currency_rates, db)


@app.task
def currency_rate():
    new_date = datetime.date.today().strftime('%Y-%m-%d')
    for base in ['AED', 'USD', 'SAR', 'EUR']:
        create_currency_rates(new_date, base)


def show(currency: str, account_id, db: Session):
    new_date = datetime.date.today()
    obj = {}
    obj['markups'] = {}
    markups = db.query(models.Account).filter(
        models.Account.id == account_id).first()
    obj['markups']['USD'] = markups.USD
    obj['markups']['AED'] = markups.AED
    obj['markups']['SAR'] = markups.SAR
    obj['markups']['EUR'] = markups.EUR

    obj['rates'] = {}

    cr_rate = db.query(models.FixerCurrencyRate).filter(models.FixerCurrencyRate.date ==
                                                        new_date, models.FixerCurrencyRate.base_currency == currency).first()
    if not cr_rate:
        cr_rate = create_currency_rates(new_date, currency)
    obj['rates'] = json.loads(cr_rate.rates)
    return obj
