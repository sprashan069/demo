import datetime

from app import models
from app.crud.base import get_ref_no
from fastapi import HTTPException, status
from sqlalchemy import or_
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session


def check_unique(request, db: Session, id=None):
    countries = db.query(models.Country).filter(
        or_(models.Country.name == request.name, models.Country.code == request.code))
    if countries:
        if id:
            countries = countries.filter(
                models.Country.ref_id != id)
    if countries.first():
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Country with name {request.name} or code {request.code} already exists.")


def get_all(db: Session):
    countries = db.query(models.Country).order_by(
        models.Country.created_at.asc()).all()
    for country in countries:
        country.id = country.ref_id
    return countries


def create(request, db: Session):
    check_unique(request, db)
    ref_id = get_ref_no("CTR")
    new_country = models.Country(
        name=request.name, code=request.code, ref_id=str(ref_id))
    try:
        db.add(new_country)
        db.commit()
        db.refresh(new_country)
        new_country.id = new_country.ref_id
        return new_country

    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def destroy(id: str, db: Session):
    country = db.query(models.Country).filter(models.Country.ref_id == id)
    record = country.first()

    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"country with id {id} not found")

    product = db.query(models.Product).filter(
        models.Product.country_id == id).first()
    if product:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Product allocated with this country id")

    deleted_at = datetime.datetime.utcnow()
    country.update({'deleted_at': deleted_at})
    regions = db.query(models.Region).filter(
        models.Region.country_id == record.ref_id)
    if regions:
        for region in regions.all():
            product = db.query(models.Product).filter(
                models.Product.region_id == region.ref_id).first()
            if product:
                raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                                    detail=f"Product allocated with {region.ref_id} region id")
        regions.update({'deleted_at': deleted_at})

    currencies = db.query(models.Currency).filter(
        models.Currency.country_id == record.ref_id)
    if currencies:
        for currency in currencies.all():
            product = db.query(models.Product).filter(
                models.Product.currency_id == currency.ref_id).first()
            if product:
                raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                                    detail=f"Product allocated with {currency.ref_id} currency id")
        currencies.update({'deleted_at': deleted_at})
    db.commit()


def update(id: str, request, db: Session):
    check_unique(request, db, id)
    country = db.query(models.Country).filter(models.Country.ref_id == id)
    record = country.first()

    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"region with id {id} not found")
    try:
        if request.name or request.name == "":
            record.name = request.name
        if request.code or request.code == "":
            record.code = request.code

        db.add(record)
        db.commit()
        db.refresh(record)
        record.id = record.ref_id
        return record
    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def show(id: str, db: Session):
    country = db.query(models.Country).filter(
        models.Country.ref_id == id).first()
    if not country:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"country with the id {id} is not available")
    country.id = country.ref_id
    return country
