from app import models
from app.crud import company
from fastapi import HTTPException
from sqlalchemy.orm import Session


def privacy_policy(db: Session):
    res = {}

    try:
        res['privacy_policy'] = db.query(models.PrivacyPolicy).filter(
            models.PrivacyPolicy.active == True).first()
    except HTTPException:
        res['privacy_policy'] = {}

    return res


def terms_and_conditions(db: Session):
    res = {}

    try:
        res['terms_and_conditions'] = db.query(models.Term).filter(
            models.Term.active == True).first()
    except HTTPException:
        res['terms_and_confitions'] = {}

    return res


def get(db: Session):
    res = {}

    # Company banner details
    try:
        res['home'] = company.get_obj(db)
    except HTTPException:
        res['home'] = {}

    # Company How it works details
    try:
        companies = db.query(models.CompanyDetail).filter(models.CompanyDetail.active == True).order_by(
            models.CompanyDetail.created_at.asc()).all()
        for obj in companies:
            obj.id = obj.ref_id
        res['how_it_works'] = companies
    except HTTPException:
        res['how_it_works'] = {}

    # Company header & footer details
    try:
        setting = db.query(models.Setting).first()
        if setting:
            obj = setting.__dict__
        else:
            obj = {}
        obj["contact_info"] = []
        for contact in (db.query(models.CompanyContact).filter(models.CompanyContact.active == True).order_by(
                models.CompanyContact.created_at.asc()).all()):
            obj["contact_info"].append(contact.__dict__)
            contact.id = contact.ref_id
        obj["footer_menu"] = []
        for menu in (db.query(models.FooterMenu).filter(models.FooterMenu.active == True).order_by(
                models.FooterMenu.created_at.asc()).all()):
            obj["footer_menu"].append(menu.__dict__)
            menu.id = menu.ref_id
        obj["social"] = []
        for social in (db.query(models.SocialMedia).filter(models.SocialMedia.active == True).order_by(
                models.SocialMedia.created_at.asc()).all()):
            obj["social"].append(social.__dict__)
            social.id = social.ref_id

        res['settings'] = obj
    except HTTPException:
        res['settings'] = {}

    # Company features details
    try:
        features = db.query(models.FeatureList).filter(models.FeatureList.active == True).order_by(
            models.FeatureList.created_at.asc()).all()
        for feature in features:
            feature.id = feature.ref_id

        res['features'] = features
    except HTTPException:
        res['features'] = {}

    try:
        plan = db.query(models.CompanyPlan).first()
        if plan:
            plan_obj = plan.__dict__
        else:
            plan_obj = {}
        plan_obj["plan_lists"] = []
        for plan_list in db.query(models.CompanyPlanList).filter(models.CompanyPlanList.active == True).order_by(
                models.CompanyPlanList.created_at.asc()).all():
            plan_obj["plan_lists"].append(plan_list.__dict__)
            plan_list.id = plan_list.ref_id

        res['pricing'] = plan_obj
    except HTTPException:
        res['pricing'] = {}

    return res
