from app import models, schemas
from fastapi import HTTPException, status
from sqlalchemy.orm import Session


def show(db: Session):
    vats = db.query(models.AccountVat).all()
    return vats


def create(request: schemas.AccountVat, db: Session):
    new_vat = models.AccountVat(
        vat=request.vat, currency=request.base_currency)
    db.add(new_vat)
    db.commit()
    db.refresh(new_vat)
    return new_vat


def update(id, request: schemas.AccountVat, db: Session):
    vats = db.query(models.AccountVat).filter(models.AccountVat.id == id)
    if not vats.first():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=f" id {id} not found")
    vats.update({'vat': request.vat, 'currency': request.base_currency})
    db.commit()
    return "updated"
