import datetime

from app import models, upload_image
from app.crud.base import get_ref_no, swap_language
from fastapi import HTTPException, status
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session


def check_unique(name, name_ar, db: Session, id=None):
    style_category = db.query(models.StyleCategory).filter(
        models.StyleCategory.name == name, models.StyleCategory.name_ar == name_ar, models.StyleCategory.admin_user_flag == True)
    if style_category:
        if id:
            style_category = style_category.filter(
                models.StyleCategory.ref_id != id)
    if style_category.first():
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Style category with name {name} or name_ar {name_ar} already exists.")


def get_category_obj(id, db):
    category = db.query(models.StyleCategory).filter(
        models.StyleCategory.ref_id == id, models.StyleCategory.admin_user_flag == True).first()

    if not category:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"Style category with id {id} not found")
    return category


def get_all(db: Session):
    style_categories = db.query(models.StyleCategory).filter(
        models.StyleCategory.admin_user_flag == True).order_by(
        models.StyleCategory.created_at.asc()).all()
    for style_category in style_categories:
        style_category.id = style_category.ref_id
        account = db.query(models.StyleCategory).filter(
            models.StyleCategory.id == style_category.account_id).first()
        if account:
            style_category.tenant = account.domain
    return style_categories


def create(name, name_ar, thumb_image, active, db):
    check_unique(name, name_ar, db)

    if name is None and name_ar is None:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Name is required")
    name, name_ar = swap_language(name, name_ar)

    ref_id = get_ref_no("STC")
    new_style_category = models.StyleCategory(
        name=name, name_ar=name_ar, thumb_image=upload_image(thumb_image), active=active, ref_id=str(ref_id), admin_user_flag=True)
    try:
        db.add(new_style_category)
        db.commit()
        db.refresh(new_style_category)
        new_style_category.id = new_style_category.ref_id
        return new_style_category

    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def destroy(id: str, db: Session):
    style_category = get_category_obj(id, db)

    styles = db.query(models.Style).filter(
        models.Style.style_category_id == style_category.ref_id)
    if styles:
        for style in styles.all():
            product = db.query(models.Product).filter(
                models.Product.style_id == style.ref_id).first()
            if product:
                raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                                    detail=f"Product allocated with {style_category.ref_id} style category id")
        styles.update({'deleted_at': datetime.datetime.utcnow()})
    style_category.deleted_at = datetime.datetime.utcnow()
    db.add(style_category)
    db.commit()


def update(id: str, name, name_ar, thumb_image, active, db: Session):
    record = get_category_obj(id, db)
    check_unique(name, name_ar, db, id)

    if name:
        record.name = name
    if name_ar:
        record.name_ar = name_ar
    if thumb_image:
        record.thumb_image = upload_image(thumb_image)
    if active is not None:
        record.active = active

    if record.name is None and record.name_ar is None:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Name is required")

    record.name, record.name_ar = swap_language(
        record.name, record.name_ar)

    db.add(record)
    db.commit()
    db.refresh(record)
    record.id = record.ref_id
    return record.__dict__


def show(id: str, db: Session):
    category = get_category_obj(id, db)
    category.id = category.ref_id
    account = db.query(models.StyleCategory).filter(
        models.StyleCategory.id == category.account_id).first()
    if account:
        category.tenant = account.domain
    return category
