import datetime
import http.client
import json
import os
import random
import re
import string
from operator import attrgetter

from app import models
from app.crud.currency_rates import create_currency_rates
from app.db.session import SessionLocal
from fastapi import HTTPException, status
from sqlalchemy import or_
from sqlalchemy.exc import SQLAlchemyError


def get_ref_no(ref):
    x = datetime.datetime.now()
    ref_no = ref + x.strftime("%m") + "".join(random.choices(
        (string.ascii_letters).upper(), k=5)) + x.strftime("%d")
    return ref_no


def get_list_ids(db, model):
    list_ids = []
    for obj in db.query(model).all():
        list_ids.append(obj.ref_id)
    return list_ids


def verify_active(active):
    return ((json.loads(active.lower())) if (type(active) == str)
            else active) if (active is not None) else None


def get_first_obj(db, model, ref_id):
    obj = db.query(model).filter(model.ref_id == ref_id).first()
    if not obj:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Object with {ref_id} not found.",
        )
    return obj


def get_vendor_obj(model, account_id, db):
    return db.query(model).filter(model.account_id == account_id).first()


def get_vendor_first_obj(model, id, account_id, db):
    obj = db.query(model).filter(
        model.ref_id == id and model.account_id == account_id).first()

    if not obj:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Object with {id} not found.",
        )
    return obj


def get_vendor_objects(model, account_id, db):
    return db.query(model).filter(model.account_id == account_id).all()


def get_admin_vendor_objects(model, account_id, db):
    return db.query(model).filter(or_(model.account_id == account_id,
                                      model.admin_user_flag == True)).all()


def get_versions(obj):
    return sorted(obj.versions, key=attrgetter('updated_at'), reverse=True)


def save_obj(new_obj, db, model):
    try:
        db.add(new_obj)
        db.commit()
        db.refresh(new_obj)
        obj = model.get_obj(db)
        return obj

    except SQLAlchemyError as e:
        error = str(e.__dict__["orig"])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def delete_records(list_ids, list_id, db, model):
    remaining = [item for item in list_ids if item not in list_id]

    if remaining:
        for ref_id in remaining:
            obj = get_first_obj(db, model, ref_id)

            obj.deleted_at = datetime.datetime.utcnow()
            db.add(obj)
            db.commit()


def not_found(parameters):
    error = []
    for parameter in parameters:
        if not parameter[0] in ['ref_id', 'id', 'price']:
            param = (' '.join(parameter[0].split('_'))).capitalize()
            if type(parameter[1]) == bool:
                if parameter[1] is None:
                    error.append(f"{param} not found")
            else:
                if not parameter[1]:
                    error.append(f"{param} not found")

    if error:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=", ".join(
                error)
        )


def not_available(model, ref_id, error, db):
    if ref_id:
        obj = db.query(model).filter(
            model.ref_id == ref_id).first()
        if not obj:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                                detail=f"{error} not available")


def get_mgc_response(request_type, end_point, payload):
    conn = http.client.HTTPSConnection(os.environ.get('MGC_BASE_URL'))

    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % os.environ.get("MGC_SECRET")
    }

    conn.request(request_type, end_point, payload, headers)
    res = conn.getresponse()
    data = res.read()
    return data.decode("utf-8")


def get_checkout_response(payment_id):
    conn = http.client.HTTPSConnection(os.environ.get('CHECKOUT_BASE_URL'))
    headers = {
        'Authorization': os.environ.get("CHECKOUT_SECRET")
    }
    conn.request("GET", f"/payments/{payment_id}", '', headers)
    res = conn.getresponse()
    data = res.read()
    return data.decode("utf-8")


def verify_color_obj(obj):
    if obj:
        match = re.search(r'^#(?:[0-9a-fA-F]{3}){1,2}$', obj)
        if not match:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                                detail=f"Please provide valid color code.")


def swap_language(en, ar):
    if en is not None and ar is None:
        ar = en
    elif ar is not None and en is None:
        en = ar

    return en, ar


def get_fixer_rates(base_currency, base_date):
    db = SessionLocal()
    fixers = db.query(models.FixerCurrencyRate).filter(
        models.FixerCurrencyRate.base_currency == base_currency, models.FixerCurrencyRate.date == base_date).first()
    if not fixers:
        fixers = create_currency_rates(base_date, base_currency)

    return fixers
