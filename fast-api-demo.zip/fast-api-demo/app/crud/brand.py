import datetime

from app import models, schemas
from app.crud.base import get_ref_no
from fastapi import HTTPException, status
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from . import map_instance


def check_unique(request, db: Session, id=None):
    brands = db.query(models.Brand).filter(models.Brand.name == request.name)
    if brands:
        if id:
            brands = brands.filter(models.Brand.ref_id != id)
    if brands.first():
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Brand with name {request.name} already exists.")


def get_all(db: Session):
    brands = db.query(models.Brand).order_by(
        models.Brand.created_at.asc()).all()
    for brand in brands:
        brand.id = brand.ref_id
    return brands


def create(request, db: Session):
    check_unique(request, db)
    ref_id = get_ref_no("BRD")
    new_brand = models.Brand(
        name=request.name, active=request.active, ref_id=str(ref_id))
    try:
        db.add(new_brand)
        db.commit()
        db.refresh(new_brand)
        new_brand.id = new_brand.ref_id
        return new_brand

    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def destroy(id: str, db: Session):
    brand = db.query(models.Brand).filter(
        models.Brand.ref_id == id)

    if not brand.first():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"brand with id {id} not found")

    product = db.query(models.Product).filter(
        models.Product.brand_id == id).first()
    if product:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Product allocated with this brand id")

    brand.update({'deleted_at': datetime.datetime.utcnow()})
    db.commit()


def update(id: str, request: schemas.UpdateBrand,  db: Session):
    check_unique(request, db, id)
    brand = db.query(models.Brand).filter(
        models.Brand.ref_id == id)
    record = brand.first()

    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"brand with id {id} not found")
    try:
        stored_account_model = schemas.Brand(**record.__dict__)
        update_data = request.dict(exclude_unset=True)
        updated_item = stored_account_model.copy(update=update_data)
        updated_record = map_instance(record, updated_item)
        db.add(updated_record)
        db.commit()
        db.refresh(updated_record)
        updated_record.id = updated_record.ref_id
        return updated_record
    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def show(id: str, db: Session):
    brand = db.query(models.Brand).filter(
        models.Brand.ref_id == id).first()
    if not brand:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"brand with the id {id} is not available")
    brand.id = brand.ref_id
    return brand
