from app import models, upload_image
from fastapi import HTTPException, status
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session


def get_obj(db):
    company = db.query(models.Company).first()
    return {} if not company else company


def save_obj(new_obj, db):
    try:
        db.add(new_obj)
        db.commit()
        db.refresh(new_obj)
        obj = get_obj(db)
        return obj

    except SQLAlchemyError as e:
        error = str(e.__dict__["orig"])
        return HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def update(banner_title, get_started_flag, banner_image, db: Session):
    companies = db.query(models.Company).all()
    uploaded_image = upload_image(banner_image)

    if not companies:
        company = models.Company(
            banner_title=banner_title,
            banner_image=uploaded_image,
            get_started_flag=get_started_flag,
        )
    else:
        company = companies[0]
        if banner_title:
            company.banner_title = banner_title
        if uploaded_image:
            company.banner_image = uploaded_image
        if get_started_flag is not None:
            company.get_started_flag = get_started_flag
    obj = save_obj(company, db)
    return obj


def show(db: Session):
    company = get_obj(db)
    return company
