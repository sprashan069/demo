import os
from datetime import datetime

import chargebee
from app import models
from app.crud.base import get_ref_no
from fastapi import HTTPException, status
from sqlalchemy.exc import SQLAlchemyError


def create(account_id, token, db):
    try:
        chargebee.configure(os.environ.get('CHARGEBEE_API_KEY'),
                            os.environ.get('CHARGEBEE_SITE'))
        result = chargebee.HostedPage.retrieve(token)
        subscription = result.hosted_page.content.subscription
        customer_id = subscription.customer_id
        subscription_id = subscription.id
        currency_code = subscription.currency_code
        item_price_id = subscription.subscription_items[0].item_price_id
        addon_price_id = subscription.subscription_items[
            1].item_price_id if subscription.subscription_items[1].item_price_id else None
        payment_id = get_ref_no('PMT')
        next_billing_at = datetime.fromtimestamp(subscription.next_billing_at)
        obj = models.ChargebeeSubscription(account_id=account_id, token=token, customer_id=customer_id,
                                           subscription_id=subscription_id, currency_code=currency_code, plan_id=item_price_id, addon_id=addon_price_id,  payment_id=payment_id)
        account_obj = db.query(models.Account).filter_by(id=account_id)
        account_obj.update({'next_billing_at': next_billing_at})

        db.add(obj)
        db.commit()
        db.refresh(obj)
        return obj
    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)
