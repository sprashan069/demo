import datetime

from app import models, upload_image
from app.crud.base import get_ref_no, swap_language
from fastapi import HTTPException, status
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session


def get_style_obj(id, db):
    style = db.query(models.Style).filter(
        models.Style.ref_id == id, models.Style.admin_user_flag == True).first()

    if not style:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"Style with id {id} not found")

    return style


def get_all(style_category_id, db: Session):
    styles = db.query(models.Style).filter(
        models.Style.admin_user_flag == True)
    exists = db.query(models.StyleCategory).filter_by(
        ref_id=style_category_id).first() is not None
    if not exists and style_category_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"Style category with id {style_category_id} does not exists.")
    if style_category_id:
        styles = styles.filter(
            models.Style.style_category_id == style_category_id)
    styles = styles.order_by(
        models.Style.created_at.asc()).all()
    for style in styles:
        style.id = style.ref_id
        account = db.query(models.Style).filter(
            models.Style.id == style.account_id).first()
        if account:
            style.tenant = account.domain
    return styles


def create(name, name_ar, image, image_ar, active, style_category_id, db: Session):
    ref_id = get_ref_no("STY")
    error = []
    obj = db.query(models.StyleCategory).filter(
        models.StyleCategory.ref_id == style_category_id, models.StyleCategory.admin_user_flag == True).first()
    if not obj:
        error.append("Style category not available")

    if name is None and name_ar is None:
        error.append("Name is required")
    else:
        name, name_ar = swap_language(name, name_ar)

    if image is None and image_ar is None:
        error.append("Image is required")
    else:
        image, image_ar = swap_language(image, image_ar)

    if error:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=", ".join(
            error))

    new_style = models.Style(name=name, name_ar=name_ar, image=upload_image(image), image_ar=upload_image(image_ar), active=active, custom=False, ref_id=str(
        ref_id), is_product=False, style_category_id=style_category_id, admin_user_flag=True)
    try:
        db.add(new_style)
        db.commit()
        db.refresh(new_style)
        new_style.id = new_style.ref_id
        return new_style

    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def destroy(id: str, db: Session):
    style = get_style_obj(id, db)
    product = db.query(models.Product).filter(
        models.Product.style_id == id).first()
    if product:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Product allocated with this style id")
    style.deleted_at = datetime.datetime.utcnow()
    db.add(style)
    db.commit()


def update(id: str, name, name_ar, image, image_ar, active, style_category_id,  db: Session):
    record = get_style_obj(id, db)
    error = []

    if name:
        record.name = name
    if name_ar:
        record.name_ar = name_ar
    if image:
        record.image = upload_image(image)
    if image_ar:
        record.image_ar = upload_image(image_ar)
    if active is not None:
        record.active = active
    if style_category_id:
        obj = db.query(models.StyleCategory).filter(
            models.StyleCategory.ref_id == style_category_id, models.StyleCategory.admin_user_flag == True).first()
        if not obj:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                                detail=f"Style category not available")
        record.style_category_id = style_category_id

    if record.name is None and record.name_ar is None:
        error.append("Name is required")
    else:
        record.name, record.name_ar = swap_language(
            record.name, record.name_ar)

    if record.image is None and record.image_ar is None:
        error.append("Image is required")
    else:
        record.image, record.image_ar = swap_language(
            record.image, record.image_ar)

    if error:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=", ".join(
            error))

    db.add(record)
    db.commit()
    db.refresh(record)
    record.id = record.ref_id
    return record.__dict__


def show(id: str, db: Session):
    style = get_style_obj(id, db)
    style.id = style.ref_id
    account = db.query(models.Style).filter(
        models.Style.id == style.account_id).first()
    if account:
        style.tenant = account.domain
    return style
