import re
from datetime import date, datetime


def map_instance(target_instance, source_instance):
    """Map an instance from source_instance to target_instance.

    Solution of 'sqlalchemy.orm.exc.UnmappedInstanceError' exception.

    For example:

    - target_instance is account
    - source_instance is updated_item

    To implement below thing simple call this function as:

    map_instance(account, updated_item)


        account.first_name = updated_item.first_name
        account.last_name = updated_item.last_name
        account.email = updated_item.email
        account.username = updated_item.username
        account.password = updated_item.password

    """
    for key, value in source_instance.__dict__.items():
        setattr(target_instance, key, value)
    return target_instance


def parse_to_dict_val(key, value, dict):
    '''
    Parses depth, encoded names into a JSON'ish dictionary structure
    '''
    patt = re.compile(
        r'(?P<name>.*?)[\[](?P<key>.*?)[\]][\[](?P<remaining>.*?)[\]]$')
    matcher = patt.match(key)
    if not matcher:
        tmp = re.split("(\[.+?\])", key)
        keys = []
        for item in tmp:
            item = item.replace('[', '').replace(']', '')
            if item:
                keys.append(item)
        tmp = keys
        if len(keys) == 2:
            if keys[0] not in dict:
                dict[keys[0]] = {}
            if keys[1] not in dict[keys[0]]:
                dict[keys[0]][keys[1]] = value
        else:
            dict[key] = value
    else:
        tmp = (matcher.groupdict() if not matcher ==
               None else {"name": key, "remaining": ''})
        if tmp['remaining'] == '':
            dict[tmp['name']] = value
        else:  # looks like we have more to do
            if not tmp['name'] in dict:
                dict[tmp['name']] = {}
            if not tmp['key'] in dict[tmp['name']]:
                dict[tmp['name']][tmp['key']] = {}
            dict[tmp['name']][tmp['key']][tmp['remaining']] = value
    return dict


def parse_to_dict_vals(dictin):
    '''
    Parses dictionary for encoded keys signifying depth
    '''
    dictout = {}
    for key, value in dictin.items():
        parse_to_dict_val(key, value, dictout)
    return dictout


def get_expiration_date(d, years):
    try:
        # Return same day of the current year
        return d.replace(year=d.year + years)
    except ValueError:
        # If not same day, it will return other, i.e.  February 29 to March 1 etc.
        return d + (date(d.year + years, 1, 1) - date(d.year, 1, 1))


def convert_expiry_date(date):
    return date if date == 'Unlimited' else datetime.strptime(date, '%Y-%m-%d').strftime('%d-%m-%Y')
