import datetime

from app import models
from app.crud.base import get_ref_no, not_available
from fastapi import HTTPException, status
from sqlalchemy import or_
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session


def check_unique(request, db: Session, id=None):
    currency = db.query(models.Currency).filter(or_(models.Currency.name == request.name,
                                                    models.Currency.code == request.code))
    if currency:
        if id:
            currency = currency.filter(
                models.Currency.ref_id != id)
    if currency.first():
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Currency with name {request.name} or code {request.code} already exists.")


def get_all(country_id, db: Session):
    currencies = db.query(models.Currency)
    exists = db.query(models.Country).filter_by(
        ref_id=country_id).first() is not None
    if not exists and country_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"Country with id {country_id} does not exists.")
    if country_id:
        currencies = currencies.filter(
            models.Currency.country_id == country_id)
    currencies = currencies.order_by(
        models.Currency.created_at.asc()).all()
    for currency in currencies:
        currency.id = currency.ref_id
        currency.country.id = currency.country.ref_id
    return currencies


def create(request, db: Session):
    check_unique(request, db)
    not_available(models.Country, request.country_id, "Country", db)
    ref_id = get_ref_no("CRC")
    new_currency = models.Currency(
        name=request.name, code=request.code, country_id=request.country_id, ref_id=str(ref_id))
    try:
        db.add(new_currency)
        db.commit()
        db.refresh(new_currency)
        new_currency.id = new_currency.ref_id
        new_currency.country.id = new_currency.country.ref_id
        return new_currency

    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        return error


def destroy(id: str, db: Session):
    currency = db.query(models.Currency).filter(
        models.Currency.ref_id == id)

    if not currency.first():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"currency with id {id} not found")

    product = db.query(models.Product).filter(
        models.Product.currency_id == id).first()
    if product:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Product allocated with this currency id")

    currency.update({'deleted_at': datetime.datetime.utcnow()})
    db.commit()


def update(id: str, request, db: Session):
    check_unique(request, db, id)
    currency = db.query(models.Currency).filter(
        models.Currency.ref_id == id)
    record = currency.first()

    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"currency with id {id} not found")
    try:
        if request.name or request.name == "":
            record.name = request.name
        if request.code or request.code == "":
            record.code = request.code
        if request.country_id:
            not_available(models.Country, request.country_id, "Country", db)
            record.country_id = request.country_id

        db.add(record)
        db.commit()
        db.refresh(record)
        record.id = record.ref_id
        record.country.id = record.country.ref_id
        return record
    except SQLAlchemyError as e:
        error = str(e.__dict__['orig'])
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error)


def show(id: str, db: Session):
    currency = db.query(models.Currency).filter(
        models.Currency.ref_id == id).first()
    if not currency:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail=f"currency with the id {id} is not available")
    currency.id = currency.ref_id
    currency.country.id = currency.country.ref_id
    return currency
