import datetime
import enum

import sqlalchemy as sa
from sqla_softdelete import SoftDeleteMixin
from sqlalchemy import (Boolean, Column, Date, DateTime, Float, ForeignKey,
                        Integer, String, Text, UniqueConstraint)
from sqlalchemy.orm import relationship
from sqlalchemy.types import Enum
from sqlalchemy_continuum import make_versioned

from app.db.session import Base

make_versioned(user_cls=None)


class AccountStatus(enum.Enum):
    ACTIVE = 'ACTIVE'
    INACTIVE = 'INACTIVE'
    PUBLISHED = 'PUBLISHED'


class CartItemStatus(enum.Enum):
    ACTIVE = 'ACTIVE'
    DELETE = 'DELETE'


class OrderStatus(enum.Enum):
    PENDING = 'PENDING'
    PLACED = 'PLACED'
    APPROVED = 'APPROVED'
    FULFILLED = 'FULFILLED'
    AWAITING = 'AWAITING'
    IN_PROCESS = 'IN_PROCESS'
    SHIPPED = 'SHIPPED'
    DELIVERED = 'DELIVERED'
    REDEEMED = 'REDEEMED'
    REPROCESS = 'REPROCESS'
    CANCELED = 'CANCELED'
    FAILED = 'FAILED'


class DeliveryMode(enum.Enum):
    EMAIL = 'EMAIL'
    SMS = 'SMS'
    BOTH = 'BOTH'


class Language(enum.Enum):
    EN = 'en'
    AR = 'ar'


class TimestampMixin():
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow,
                        onupdate=datetime.datetime.utcnow)

class Account(Base, TimestampMixin):
    __tablename__ = 'accounts'
    __versioned__ = {}

    id = Column(Text(), primary_key=True, index=True)
    active = Column(Boolean, default=True)
    publish = Column(Boolean, default=False)
    company_name = Column(Text())
    sub = Column(Text())
    cloudfront_id = Column(Text())
    email = Column(Text())
    domain = Column(Text())
    cloudfront_resource_name = Column(Text())
    AED = Column(Float)
    USD = Column(Float)
    EUR = Column(Float)
    SAR = Column(Float)
    base_currency = Column(String(50))
    subscription_charge = Column(Float)
    vat = Column(Float)
    account_status = Column(Enum(AccountStatus), default=AccountStatus.ACTIVE)
    name = Column(String(100))
    company_address = Column(Text)
    country_id = Column(Integer, ForeignKey('country.id'))
    city_id = Column(Integer, ForeignKey('cities.id'))
    state_id = Column(Integer, ForeignKey('states.id'))
    postal_code = Column(String(100))
    company_photo = Column(Text)
    default_currency_selected = Column(Boolean, default=False)
    subscription_date = Column(DateTime)
    trial_end_at = Column(DateTime)
    last_billing_at = Column(DateTime)
    billing_day = Column(Integer)
    next_billing_at = Column(DateTime)

    country = relationship(
        "Countries", back_populates="account")
    city = relationship(
        "Cities", back_populates="account")
    state = relationship(
        "States", back_populates="account")
    chargebee = relationship(
        "ChargebeeSubscription", back_populates="account")


class AccountVat(Base, TimestampMixin):
    __tablename__ = 'account_vat'

    id = Column(Integer, primary_key=True, index=True)
    currency = Column(String(100))
    vat = Column(Float)


class Country(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'countries'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(100), unique=True, nullable=False)
    name = Column(String(100), nullable=False)
    code = Column(String(100), nullable=False)

    regions = relationship(
        "Region", back_populates="country")
    currencies = relationship(
        "Currency", back_populates="country")
    products = relationship(
        "Product", back_populates="country")


class Region(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'regions'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(100), unique=True, nullable=False)
    name = Column(String(100), nullable=False)
    subregion_name = Column(String(100))
    country_id = Column(String(100), ForeignKey(
        'countries.ref_id'), nullable=False)

    country = relationship("Country", back_populates="regions")
    products = relationship(
        "Product", back_populates="region")


class Currency(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'currencies'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(100), unique=True, nullable=False)
    name = Column(String(100), nullable=False)
    code = Column(String(100), nullable=False)
    country_id = Column(String(100), ForeignKey(
        'countries.ref_id'), nullable=False)

    country = relationship("Country", back_populates="currencies")
    products = relationship(
        "Product", back_populates="currency")


class Brand(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'brands'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    active = Column(Boolean, default=True)
    ref_id = Column(String(100), unique=True, nullable=False)

    products = relationship(
        "Product", back_populates="brand")


class Category(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'categories'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    ref_id = Column(String(100), unique=True, nullable=False)

    sub_categories = relationship(
        "SubCategory", back_populates="category")
    products = relationship(
        "Product", back_populates="category")


class SubCategory(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'sub_categories'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    category_id = Column(String(100), ForeignKey(
        'categories.ref_id'), nullable=False)
    ref_id = Column(String(100), unique=True, nullable=False)

    category = relationship("Category", back_populates="sub_categories")
    products = relationship(
        "Product", back_populates="sub_category")


class Product(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'products'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(100), unique=True, nullable=False)
    active = Column(Boolean, default=True)
    account_id = Column(Text)
    name = Column(String(100), nullable=False)
    brand_id = Column(String(100), ForeignKey('brands.ref_id'), nullable=False)
    country_id = Column(String(100), ForeignKey(
        'countries.ref_id'), nullable=False)
    region_id = Column(String(100), ForeignKey(
        'regions.ref_id'), nullable=False)
    currency_id = Column(String(100), ForeignKey(
        'currencies.ref_id'), nullable=False)
    category_id = Column(String(100), ForeignKey(
        'categories.ref_id'), nullable=False)
    sub_category_id = Column(String(100), ForeignKey(
        'sub_categories.ref_id'), nullable=False)
    style_id = Column(String(100), ForeignKey('styles.ref_id'), nullable=False)
    product_image = Column(Text,  nullable=True)
    expiration_period = Column(Integer, default=1)
    description = Column(Text)
    description_ar = Column(Text)
    terms = Column(Text)
    terms_ar = Column(Text)
    how_to_redeem = Column(Text)
    how_to_redeem_ar = Column(Text)
    is_default = Column(Boolean, default=False)
    mgc_product_id = Column(Text)
    is_quantity = Column(Boolean, default=True)
    is_range = Column(Boolean, default=True)
    is_fix_amount = Column(Boolean, default=True)
    min_value = Column(Float, default=0)
    max_value = Column(Float, default=0)
    admin_denominations = Column(Text)
    denominations = Column(Text)
    is_email = Column(Boolean, default=True)
    is_sms = Column(Boolean, default=False)
    publish = Column(Boolean, default=False)

    country = relationship("Country", back_populates="products")
    region = relationship("Region", back_populates="products")
    currency = relationship("Currency", back_populates="products")
    brand = relationship("Brand", back_populates="products")
    category = relationship("Category", back_populates="products")
    sub_category = relationship("SubCategory", back_populates="products")
    style = relationship("Style", back_populates="products")
    orders = relationship(
        "Order", back_populates="product")


class StyleCategory(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'style_categories'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(100), unique=True, nullable=False)
    active = Column(Boolean, default=True)
    account_id = Column(Text)
    admin_user_flag = Column(Boolean, default=True)
    name = Column(String(100), nullable=False)
    name_ar = Column(String(100))
    thumb_image = Column(Text, nullable=False)
    publish = Column(Boolean, default=False)

    styles = relationship(
        "Style", back_populates="style_category")


class Style(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = "styles"
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(100), unique=True, nullable=False)
    active = Column(Boolean, default=True)
    account_id = Column(Text)
    admin_user_flag = Column(Boolean, default=True)
    style_category_id = Column(String(100), ForeignKey(
        StyleCategory.ref_id))
    name = Column(String(100))
    name_ar = Column(String(100))
    image = Column(Text, nullable=False)
    image_ar = Column(Text)
    custom = Column(Boolean, default=False)
    is_product = Column(Boolean, default=False)
    is_default = Column(Boolean, default=False)
    publish = Column(Boolean, default=False)

    products = relationship('Product', back_populates='style')
    style_category = relationship(
        "StyleCategory", back_populates="styles")
    orders = relationship(
        "Order", back_populates="style")


class CartItem(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'cart_items'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(100), unique=True, nullable=False)
    # account_id = Column(Integer, ForeignKey('accounts.id'), nullable=True)
    product_id = Column(Integer, ForeignKey('products.id'), nullable=False)
    status = Column(Enum(CartItemStatus), default=CartItemStatus.ACTIVE)
    quantity = Column(Integer, nullable=False)


class FAQ(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'faqs'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False)
    active = Column(Boolean, default=True)
    sort_order = Column(Integer)
    question = Column(Text)
    answer = Column(Text)


class PrivacyPolicy(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'privacy_policies'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False)
    active = Column(Boolean, default=True)
    description = Column(Text)
    link = Column(Text)


class Contact(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'contacts'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False)
    name = Column(String(50), nullable=False)
    email = Column(String(50), nullable=False)
    role = Column(Text, nullable=False)
    message = Column(Text, nullable=False)


class Term(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'terms'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False)
    active = Column(Boolean, default=True)
    terms_text = Column(Text)
    link = Column(Text)


class SocialMedia(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'social_medias'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False)
    active = Column(Boolean, default=True)
    icon = Column(Text)
    link = Column(Text)


class Company(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'companies'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    banner_title = Column(Text)
    banner_image = Column(Text)
    get_started_flag = Column(Boolean, default=True)


class Setting(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'settings'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    header_title = Column(Text)
    header_logo = Column(Text)
    footer_logo = Column(Text)
    copy_right = Column(Text)


class CompanyContact(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'company_contacts'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False)
    active = Column(Boolean, default=True)
    title = Column(Text)
    description = Column(Text)


class FooterMenu(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'footer_menus'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False)
    active = Column(Boolean, default=True)
    title = Column(Text)
    link = Column(Text)


class CompanyDetail(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'company_details'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False)
    active = Column(Boolean, default=True)
    title = Column(Text)
    sub_title = Column(Text)
    description = Column(Text)
    image = Column(Text)


class FeatureList(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'feature_lists'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False, unique=True, index=True)
    active = Column(Boolean, default=True)
    title = Column(Text)
    description = Column(Text)
    image = Column(Text)


class CompanyPlan(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'company_plans'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False, unique=True, index=True)
    title = Column(Text)
    description = Column(Text)

    company_plan_lists = relationship(
        "CompanyPlanList", back_populates="company_plan")


class CompanyPlanList(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'company_plan_lists'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False, unique=True, index=True)
    active = Column(Boolean, default=True)
    company_plan_id = Column(String(50), ForeignKey(
        CompanyPlan.ref_id), nullable=False)
    title = Column(Text)
    sub_title = Column(Text)
    price = Column(String(100))
    feature_list = Column(Text)
    button_text = Column(Text)

    company_plan = relationship(
        "CompanyPlan", back_populates="company_plan_lists")


class VendorBannerImage(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'vendor_banner_images'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False, unique=True, index=True)
    account_id = Column(Text)
    banner_image = Column(Text)
    language = Column(Enum(Language), default=Language.EN)
    publish = Column(Boolean, default=False)

    vendor_banners = relationship(
        "VendorBanner", back_populates="vendor_banner_image")


class VendorBanner(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'vendor_banners'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False, unique=True, index=True)
    account_id = Column(Text)
    title = Column(Text)
    image_id = Column(String(50), ForeignKey(
        VendorBannerImage.ref_id))
    image_ar_id = Column(String(50))
    title_ar = Column(Text)
    publish = Column(Boolean, default=False)

    vendor_banner_image = relationship(
        "VendorBannerImage", back_populates="vendor_banners")


class VendorSetting(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'vendor_settings'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Text)
    header_title = Column(Text)
    header_logo = Column(Text)
    card_image = Column(Text)
    copy_right = Column(Text)
    primary_color = Column(Text)
    secondary_color = Column(Text)
    publish = Column(Boolean, default=False)


class VendorFAQ(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'vendor_faqs'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False)
    active = Column(Boolean, default=True)
    account_id = Column(Text)
    sort_order = Column(Integer)
    question = Column(Text)
    answer = Column(Text)
    publish = Column(Boolean, default=False)


class VendorTerm(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'vendor_terms'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False)
    active = Column(Boolean, default=True)
    account_id = Column(Text)
    terms_text = Column(Text)
    publish = Column(Boolean, default=False)


class VendorPrivacyPolicy(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'vendor_privacy_policies'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False)
    active = Column(Boolean, default=True)
    account_id = Column(Text)
    description = Column(Text)
    publish = Column(Boolean, default=False)


class VendorContact(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'vendor_contacts'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), nullable=False)
    account_id = Column(Text)
    name = Column(String(50))
    email = Column(String(50))
    message = Column(Text)


class VendorContactSetting(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'vendor_contacts_settings'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Text)
    phone_number = Column(String(50), nullable=False)
    email = Column(String(50), nullable=False)
    location = Column(Text)


class Order(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'orders'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), unique=True, nullable=False)
    account_id = Column(Text)
    product_id = Column(String(50), ForeignKey(Product.ref_id))
    status = Column(Enum(OrderStatus), default=OrderStatus.PENDING)
    language = Column(String(50))
    quantity = Column(Integer, nullable=False)
    amount = Column(Float, nullable=False)
    total = Column(Float, nullable=False)
    markup_rate = Column(Float)
    payment_amount = Column(Float)
    payment_currency = Column(String(50))
    style_id = Column(String(50), ForeignKey(
        Style.ref_id))

    __table_args__ = (UniqueConstraint("ref_id"),)
    product = relationship("Product", back_populates="orders")
    style = relationship("Style", back_populates="orders")
    order_details = relationship(
        "OrderDetail", back_populates="order")
    order_delivery_details = relationship(
        "OrderDeliveryDetail", back_populates="order")
    merit_order_details = relationship(
        "MeritOrderDetail", back_populates="order")
    order_payment_details = relationship(
        "OrderPaymentDetail", back_populates="order")
    billing_orders = relationship("BillingOrders", back_populates="order")


class OrderDetail(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'order_details'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(String(50), ForeignKey(Order.ref_id), nullable=False)
    order_detail_status = Column(
        Enum(OrderStatus), default=OrderStatus.PENDING)
    tracking_id = Column(Text)
    tracking_url = Column(Text)
    description = Column(Text)
    error_message = Column(Text)

    __table_args__ = (UniqueConstraint(
        "order_id", "order_detail_status"),)
    order = relationship(
        "Order", back_populates="order_details")


class OrderPaymentDetail(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'order_payment_details'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), unique=True, nullable=False)
    order_id = Column(String(50), ForeignKey(Order.ref_id), nullable=False)
    payment_id = Column(Text, unique=True)
    customer_id = Column(Text)
    payment_status = Column(Text)
    payment_success = Column(Boolean, nullable=False, default=False)
    error_message = Column(Text)

    order = relationship(
        "Order", back_populates="order_payment_details")


class MeritOrderDetail(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'merit_order_details'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), unique=True, nullable=False)
    order_id = Column(String(50), ForeignKey(Order.ref_id), nullable=False)
    order_reference_id = Column(String(50))
    batch_id = Column(String(50))
    error_message = Column(Text)

    order = relationship(
        "Order", back_populates="merit_order_details")
    merit_giftcards = relationship(
        "MeritGiftcard", back_populates="merit_order_detail")


class MeritGiftcard(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'merit_giftcards'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    ref_id = Column(String(50), unique=True, nullable=False)
    merit_order_detail_id = Column(
        String(50), ForeignKey(MeritOrderDetail.ref_id), nullable=False)
    giftcard_number = Column(String(100))
    card_id = Column(String(100))
    amount = Column(Float)
    giftcard_pin = Column(String(100))
    product_id = Column(String(100))
    expiration_date = Column(String(100))
    currency = Column(String(50))

    merit_order_detail = relationship(
        "MeritOrderDetail", back_populates="merit_giftcards")


class OrderDeliveryDetail(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'order_delivery_details'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(String(50), ForeignKey(Order.ref_id), nullable=False)
    sender_name = Column(String(100), nullable=False)
    recipient_email = Column(String(100), nullable=False)
    phone_number = Column(String(30))
    recipient_name = Column(String(100))
    message = Column(Text)
    delivery_timestamp = Column(Text)
    # TODO: Find solution for deliivery_mode & deliverymode
    delivery_mode = Column(
        Enum(DeliveryMode), default=DeliveryMode.EMAIL)
    buy_for_self = Column(Boolean, nullable=False, default=False)

    __table_args__ = (UniqueConstraint("order_id"),)
    order = relationship(
        "Order", back_populates="order_delivery_details")


class FixerCurrencyRate(Base, TimestampMixin):
    __tablename__ = 'fixer_currency_rates'

    id = Column(Integer, primary_key=True, index=True)
    date = Column(Date)
    rates = Column(Text)
    base_currency = Column(String(50))


class ChargebeeSubscription(Base, TimestampMixin):
    __tablename__ = 'chargebee_subscription'

    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Text, ForeignKey('accounts.id'))
    token = Column(String(100))
    customer_id = Column(String(100))
    subscription_id = Column(String(100))
    currency_code = Column(String(10))
    plan_id = Column(String(100))
    addon_id = Column(String(100))
    payment_id = Column(Text)

    account = relationship(
        "Account", back_populates="chargebee")


class BillingOrders(Base, TimestampMixin):
    __tablename__ = 'billing_orders'

    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Text)
    name = Column(String(100), nullable=False)
    order_id = Column(String(50), ForeignKey(Order.ref_id), nullable=False)
    amount = Column(Float)
    currency = Column(String(50))
    rates = Column(Text)
    total_amount = Column(Float)

    order = relationship(
        "Order", back_populates="billing_orders")


class Invoice(Base, TimestampMixin):
    __tablename__ = 'invoices'

    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Text)
    from_date = Column(Date)
    to_date = Column(Date)
    total_amount = Column(Float)
    subscription_charge = Column(Float)
    subscription_amount = Column(Float)
    subscription_id = Column(Text)


class Countries(Base):
    __tablename__ = 'country'

    id = Column(Integer, primary_key=True)
    name = Column(String(100))
    iso3 = Column(String(10))
    iso2 = Column(String(10))
    phone_code = Column(String(50))
    capital = Column(String(100))
    currency = Column(String(50))
    region = Column(String(100))
    latitude = Column(Float)
    longitude = Column(Float)

    account = relationship(
        "Account", back_populates="country")


class States(Base):
    __tablename__ = 'states'

    id = Column(Integer, primary_key=True)
    name = Column(String(100))
    country_id = Column(Integer)
    country_code = Column(String(10))
    state_code = Column(String(10))
    latitude = Column(Float)
    longitude = Column(Float)

    account = relationship(
        "Account", back_populates="state")


class Cities(Base):
    __tablename__ = 'cities'

    id = Column(Integer, primary_key=True)
    name = Column(String(100))
    state_id = Column(Integer)
    state_code = Column(String(10))
    country_id = Column(Integer)
    country_code = Column(String(10))
    latitude = Column(Float)
    longitude = Column(Float)

    account = relationship(
        "Account", back_populates="city")


class WhitelistIPs(SoftDeleteMixin, Base, TimestampMixin):
    __tablename__ = 'whitelist_ips'
    __versioned__ = {}

    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Text)
    whitelist_ip = Column(Text)


class ChargebeeInvoiceEvents(Base, TimestampMixin):
    __tablename__ = 'chargebee_invoice_event'

    id = Column(Integer, primary_key=True, index=True)
    subscription_id = Column(String(100))
    customer_id = Column(Text)
    invoice_status = Column(String(100))
    event_id = Column(Text)
    event_type = Column(Text)
    plan_price = Column(Float)
    addon_price = Column(Float)

sa.orm.configure_mappers()
