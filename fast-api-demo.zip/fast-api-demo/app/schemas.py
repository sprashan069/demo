from datetime import date, datetime
from typing import List, Optional

from pydantic import BaseModel, Field

from .models import AccountStatus, DeliveryMode, Language, OrderStatus


class TimestampMixin:
    created_at: datetime
    updated_at: datetime


class AccountToken(BaseModel):
    token: str

    class Config():
        orm_mode = True


class AccountMarkup(BaseModel):
    AED: Optional[float]
    EUR: Optional[float]
    SAR: Optional[float]
    USD: Optional[float]
    subscription_charge: Optional[float]
    base_currency: Optional[str]
    account_status: Optional[AccountStatus]

    class Config():
        orm_mode = True


class AccountVat(AccountMarkup):
    vat: Optional[float] = Field(ge=1, le=100)

    class Config():
        orm_mode = True


class AllAccountDetail(AccountVat):
    id: Optional[str]
    publish: Optional[bool]
    company_name: Optional[str]
    created_at: datetime
    sub: Optional[str]
    email: Optional[str]
    domain: Optional[str]
    trial_date: Optional[datetime]
    default_currency_selected: Optional[bool]
    subscription_date: Optional[datetime]
    trial_end_at: Optional[datetime]
    next_billing_at: Optional[datetime]

    class Config():
        orm_mode = True


class Account(BaseModel):
    username: Optional[str]
    email: Optional[str]

    class Config():
        orm_mode = True


class AccountDetail(BaseModel):
    sub_domain: Optional[str]
    account_status: Optional[AccountStatus]
    remaining_days: Optional[int]
    trial_end_at: Optional[date]

    class Config():
        orm_mode = True


class VendorAccountdetail(BaseModel):
    id: Optional[str]
    name: Optional[str]
    company_name: Optional[str]
    company_address: Optional[str]
    country: Optional[str]
    city: Optional[str]
    state: Optional[str]
    postal_code: Optional[str]
    company_photo: Optional[str]
    email: Optional[str]

    class Config():
        orm_mode = True


class BillingDetails(BaseModel):
    name: Optional[str]
    recipient_email: Optional[str]
    created_at: Optional[datetime]
    order_id: Optional[str]
    quantity: Optional[int]
    amount: Optional[float]
    currency: Optional[str]
    rates: Optional[float]
    total_amount: Optional[float]
    base_total_amount: Optional[float]

    class Config():
        orm_mode = True


class InvoiceDetail(BaseModel):
    account_id: Optional[str]
    from_date: Optional[date]
    to_date: Optional[date]
    total_amount: Optional[float]
    subscription_charge: Optional[float]
    subscription_amount: Optional[float]
    subscription_id: Optional[str]
    base_currency: Optional[str]
    next_billing_at: Optional[datetime]

    class Config():
        orm_mode = True


class Country(BaseModel, TimestampMixin):
    name: Optional[str]
    code: Optional[str]

    class Config():
        orm_mode = True


class ShowCountry(BaseModel):
    id: str
    name: Optional[str]
    code: Optional[str]

    class Config():
        orm_mode = True


class Region(BaseModel, TimestampMixin):
    name: Optional[str]
    subregion_name: Optional[str]

    class Config():
        orm_mode = True


class UpdateRegion(Region):
    country_id: Optional[str]

    class Config():
        orm_mode = True


class ShowRegion(Region):
    id: str
    country: ShowCountry

    class Config():
        orm_mode = True


class RegionDetail(BaseModel):
    id: str
    name: Optional[str]
    subregion_name: Optional[str]

    class Config():
        orm_mode = True


class Currency(BaseModel, TimestampMixin):
    name: Optional[str]
    code: Optional[str]

    class Config():
        orm_mode = True


class CurrencyDetail(Currency):
    id: Optional[str]
    country_id: Optional[str]

    class Config():
        orm_mode = True


class ProductCurrencyDetail(BaseModel):
    id: Optional[str]
    name: Optional[str]
    code: Optional[str]
    country: Optional[ShowCountry]

    class Config():
        orm_mode = True


class UpdateCurrency(Currency):
    country_id: Optional[str]

    class Config():
        orm_mode = True


class ShowCurrency(Currency):
    id: str
    country: ShowCountry

    class Config():
        orm_mode = True


class Brand(BaseModel, TimestampMixin):
    name: str
    active: bool

    class Config():
        orm_mode = True


class UpdateBrand(BaseModel, TimestampMixin):
    name: Optional[str]
    active: Optional[bool]

    class Config():
        orm_mode = True


class ShowBrand(Brand):
    id: str

    class Config():
        orm_mode = True


class Category(BaseModel, TimestampMixin):
    name: str

    class Config():
        orm_mode = True


class UpdateCategory(BaseModel, TimestampMixin):
    name: Optional[str]

    class Config():
        orm_mode = True


class ShowCategory(Category):
    id: str

    class Config():
        orm_mode = True


class SubCategory(BaseModel, TimestampMixin):
    name: str
    category_id: str

    class Config():
        orm_mode = True


class UpdateSubCategory(BaseModel, TimestampMixin):
    name: Optional[str]
    category_id: Optional[str]

    class Config():
        orm_mode = True


class ShowSubCategory(SubCategory):
    id: str

    class Config():
        orm_mode = True


class Contacts(BaseModel):
    name: str
    email: str
    role: str
    message: str

    class Config():
        orm_mode = True


class ShowContacts(Contacts):
    id: str

    class Config():
        orm_mode = True


class ContactList(BaseModel):
    contacts: Optional[List[ShowContacts]]

    class Config():
        orm_mode = True


class Product(BaseModel, TimestampMixin):
    name: Optional[str]
    active: Optional[bool]
    is_default: Optional[bool]
    brand_id: Optional[str]
    country_id: Optional[str]
    region_id: Optional[str]
    category_id: Optional[str]
    sub_category_id: Optional[str]
    style_id: Optional[str]
    product_image: Optional[str]
    expiration_period: Optional[int] = 1
    description: Optional[str]
    terms: Optional[str]
    how_to_redeem: Optional[str]
    mgc_product_id: Optional[str]

    class Config():
        orm_mode = True


class ShowProduct(Product):
    id: Optional[str]

    class Config():
        orm_mode = True


class StyleDetail(BaseModel):
    id: Optional[str]
    name: Optional[str]
    name_ar: Optional[str]
    image: Optional[str]
    image_ar: Optional[str]
    active: Optional[bool]
    style_category_id: Optional[str]
    admin_user_flag: Optional[bool]
    tenant: Optional[str]

    class Config():
        orm_mode = True


class StyleCategoryDetail(BaseModel):
    id: Optional[str]
    name: Optional[str]
    name_ar: Optional[str]
    thumb_image: Optional[str]
    active: Optional[bool]
    admin_user_flag: Optional[bool]
    tenant: Optional[str]

    class Config():
        orm_mode = True


class ProductStyleDetail(BaseModel):
    id: Optional[str]
    name: Optional[str]
    name_ar: Optional[str]
    image: Optional[str]
    image_ar: Optional[str]
    active: Optional[bool]
    custom: Optional[bool]
    admin_user_flag: Optional[bool]
    style_category: Optional[StyleCategoryDetail]

    class Config():
        orm_mode = True


class BaseProductDetail(BaseModel):
    id: Optional[str]
    name: Optional[str]
    active: Optional[bool]
    currency_id: Optional[str]
    currency_code: Optional[str]
    product_image: Optional[str]
    expiration_period: Optional[int] = 1
    is_quantity: Optional[bool]
    is_range: Optional[bool]
    is_fix_amount: Optional[bool]
    min_value: Optional[float]
    max_value: Optional[float]
    denominations: Optional[str]
    admin_denominations: Optional[str]
    is_email: Optional[bool]
    is_sms: Optional[bool]
    description: Optional[str]
    description_ar: Optional[str]
    terms: Optional[str]
    terms_ar: Optional[str]
    how_to_redeem: Optional[str]
    how_to_redeem_ar: Optional[str]

    class Config():
        orm_mode = True


class ProductDetail(BaseProductDetail):
    is_default: Optional[bool]
    mgc_product_id: Optional[str]
    country: Optional[ShowCountry]
    region: Optional[RegionDetail]
    brand: Optional[ShowBrand]
    category: Optional[ShowCategory]
    sub_category: Optional[ShowSubCategory]
    style: Optional[StyleDetail]


class VendorProductDetail(BaseProductDetail):
    style: Optional[ProductStyleDetail]


class ProductList(BaseModel):
    id: Optional[str]
    name: Optional[str]
    active: Optional[bool]
    tenant: Optional[str]
    country_name: Optional[str]
    brand_name: Optional[str]
    category_name: Optional[str]
    sub_category_name: Optional[str]
    expiration_period: Optional[int]
    min_value: Optional[float]
    max_value: Optional[float]
    currency_name: Optional[str]
    mgc_product_id: Optional[str]

    class Config():
        orm_mode = True


class GetProducts(BaseModel):
    id: Optional[str]
    name: Optional[str]
    active: Optional[bool]

    class Config():
        orm_mode = True


class OrderDeliveryDetail(BaseModel, TimestampMixin):
    order_id: int
    sender_name: str
    recipient_name: str
    recipient_email: str
    phone_number: str
    message: str
    delivery_timestamp: str
    delivery_mode: DeliveryMode
    buy_for_self: bool

    class Config:
        orm_mode = True


class CreateOrderDetail(BaseModel, TimestampMixin):
    order_id: int
    order_detail_status: str
    tracking_id: Optional[str]
    tracking_url: Optional[str]
    description: str

    class Config:
        orm_mode = True


class OrderPayment(BaseModel, TimestampMixin):
    payment_id: Optional[str]
    customer_id: Optional[str]
    payment_status: Optional[str]
    payment_success: Optional[bool]
    error_message: Optional[str]

    class Config:
        orm_mode = True


class Order(BaseModel, TimestampMixin):
    account_id: Optional[str]
    ref_id: str
    product_id: Optional[str]
    status: OrderStatus
    quantity: Optional[int]
    amount: float
    total: float
    style_id: Optional[int]

    class Config:
        orm_mode = True
        use_enum_values = True


class CreateOrder(BaseModel, TimestampMixin):
    account_id: str
    product_id: int
    status: OrderStatus
    quantity: int
    style_id: int

    class Config:
        orm_mode = True
        use_enum_values = True


class PlaceOrder(BaseModel):
    product_id: str
    quantity: Optional[int]
    amount: float
    buy_for_self: bool
    delivery_mode: Optional[DeliveryMode]
    style_id: str
    recipient_name: Optional[str]
    sender_name: str
    recipient_email: str
    phone_number: Optional[str]
    message: Optional[str]
    language: Optional[str]
    delivery_timestamp: Optional[str]

    class Config:
        orm_mode = True
        use_enum_values = True


class OrderProductDetail(BaseModel):
    ref_id: Optional[str]
    name: Optional[str]
    product_image: Optional[str]
    expiration_period: Optional[int] = 1
    description: Optional[str]
    description_ar: Optional[str]
    terms: Optional[str]
    terms_ar: Optional[str]
    how_to_redeem: Optional[str]
    how_to_redeem_ar: Optional[str]
    mgc_product_id: Optional[str]

    class Config:
        orm_mode = True


class OrderCurrencyDetail(BaseModel):
    ref_id: Optional[str]
    name: Optional[str]
    code: Optional[str]

    class Config:
        orm_mode = True


class OrderDetail(BaseModel):
    orderId: Optional[str]
    createdAt: Optional[datetime]
    orderStatus: Optional[OrderStatus]
    quantity: Optional[int]
    amount: Optional[float]
    expirationDate: Optional[str]
    orderTotal: Optional[float]
    markupRate: Optional[float]
    paymentAmount: Optional[float]
    paymentCurrency: Optional[str]
    styleId: Optional[str]
    name: Optional[str]
    recipientName: Optional[str]
    recipientEmail: Optional[str]
    phoneNumber: Optional[str]
    message: Optional[str]
    deliveryDate: Optional[str]
    deliveryMode: Optional[DeliveryMode]
    buyingForSelf: Optional[bool]
    customer_id: Optional[str]
    error_message: Optional[str]
    language: Optional[str]
    product: Optional[OrderProductDetail]
    currency: Optional[OrderCurrencyDetail]


class Orders(BaseModel):
    orders: Optional[List[OrderDetail]]


class OrderList(BaseModel):
    data: Optional[Orders]
    total: Optional[int]


class OrderFetch(BaseModel):
    order: Optional[OrderDetail]


class OrderCancel(BaseModel):
    reason: Optional[str]


class OrderStatusCount(BaseModel):
    total_orders: Optional[int]
    pending_orders: Optional[int]
    approved_orders: Optional[int]
    fulfilled_orders: Optional[int]
    failed_orders: Optional[int]
    canceled_orders: Optional[int]

    class Config:
        orm_mode = True


class FAQ(BaseModel, TimestampMixin):
    active: bool
    ref_id: Optional[str]
    sort_order: int
    question: str
    answer: str


class ShowFAQ(BaseModel):
    faqs: Optional[List[FAQ]]

    class Config:
        orm_mode = True


class PrivacyPolicy(BaseModel, TimestampMixin):
    active: Optional[bool]
    description: Optional[str]
    link: Optional[str]

    class Config:
        orm_mode = True


class PrivacyPolicyObj(BaseModel):
    active: Optional[bool]
    description: Optional[str]

    class Config:
        orm_mode = True


class LandingPagePrivacyPolicy(BaseModel):
    privacy_policy: Optional[PrivacyPolicyObj]

    class Config:
        orm_mode = True


class Contact(BaseModel, TimestampMixin):
    name: str
    email: str
    phone_number: Optional[str]
    subject: Optional[str]
    message: Optional[str]


class Term(BaseModel, TimestampMixin):
    active: Optional[bool]
    terms_text: Optional[str]
    link: Optional[str]

    class Config:
        orm_mode = True


class TermObj(BaseModel):
    active: Optional[bool]
    terms_text: Optional[str]

    class Config:
        orm_mode = True


class LandingPageTerm(BaseModel):
    terms_and_conditions: Optional[TermObj]

    class Config:
        orm_mode = True


class Company(BaseModel, TimestampMixin):
    banner_title: str
    get_started_flag: bool

    class Config:
        orm_mode = True


class HomePage(BaseModel):
    banner_title: Optional[str]
    banner_image: Optional[str]
    get_started_flag: Optional[bool]

    class Config:
        orm_mode = True


class Header(BaseModel, TimestampMixin):
    header_title: Optional[str]
    header_logo: Optional[str]
    footer_logo: Optional[str]
    copy_right: Optional[str]


class CompanyContact(BaseModel, TimestampMixin):
    id: Optional[str]
    active: Optional[bool]
    title: Optional[str]
    description: Optional[str]


class CompanyContactList(BaseModel):
    contact_info: Optional[List[CompanyContact]]


class FooterMenu(BaseModel, TimestampMixin):
    id: Optional[str]
    active: Optional[bool]
    title: Optional[str]
    link: Optional[str]


class FooterMenuList(BaseModel):
    footer_menu: Optional[List[FooterMenu]]


class SocialMedia(BaseModel, TimestampMixin):
    id: Optional[str]
    active: Optional[bool]
    icon: Optional[str]
    link: Optional[str]


class Setting(Header):
    contact_info: Optional[List[CompanyContact]]
    footer_menu: Optional[List[FooterMenu]]
    social: Optional[List[SocialMedia]]

    class Config:
        orm_mode = True


class CompanyDetail(BaseModel, TimestampMixin):
    active: Optional[bool]
    title: Optional[str]
    sub_title: Optional[str]
    description: Optional[str]
    image: Optional[str]


class ShowCompanyDetail(CompanyDetail, TimestampMixin):
    id: str

    class Config:
        orm_mode = True


class Feature(BaseModel):
    id: str
    title: str
    description: Optional[str]
    image: str
    active: bool

    class Config:
        orm_mode = True


class CompanyPlan(BaseModel, TimestampMixin):
    title: Optional[str]
    description: Optional[str]


class CompanyPlanList(BaseModel, TimestampMixin):
    id: Optional[str]
    active: Optional[bool]
    title: Optional[str]
    sub_title: Optional[str]
    price: Optional[str]
    feature_list: Optional[str]
    button_text: Optional[str]


class ShowCompanyPlan(CompanyPlan):
    plan_lists: Optional[List[CompanyPlanList]]

    class Config:
        orm_mode = True


class LandingPage(BaseModel):
    home: Optional[HomePage]
    how_it_works: Optional[List[ShowCompanyDetail]]
    settings: Optional[Setting]
    features: Optional[List[Feature]]
    pricing: Optional[ShowCompanyPlan]

    class Config:
        orm_mode = True


class ShowVendorBannerImage(BaseModel):
    id: Optional[str]
    banner_image: Optional[str]

    class Config:
        orm_mode = True


class VendorBannerImage(ShowVendorBannerImage):
    language: Optional[Language]


class VendorBannerImagesInLanguages(BaseModel):
    en: List[ShowVendorBannerImage]
    ar: List[ShowVendorBannerImage]


class BaseVendorBanner(BaseModel):
    title: Optional[str]
    title_ar: Optional[str]

    class Config:
        orm_mode = True


class VendorBanner(BaseVendorBanner):
    image_id: Optional[str]
    image_ar_id: Optional[str]


class VendorBannerDetail(BaseVendorBanner):
    banner_image: Optional[str]
    banner_image_ar: Optional[str]


class VendorHeader(BaseModel):
    header_logo: Optional[str]

    class Config:
        orm_mode = True


class VendorSetting(VendorHeader):
    copy_right: Optional[str]
    primary_color: Optional[str]
    secondary_color: Optional[str]


class VendorFaq(BaseModel):
    id: Optional[str]
    active: Optional[bool]
    sort_order: Optional[int]
    question: Optional[str]
    answer: Optional[str]

    class Config:
        orm_mode = True


class VendorFaqList(BaseModel):
    faqs: Optional[List[VendorFaq]]

    class Config:
        orm_mode = True


class VendorTerm(BaseModel):
    active: Optional[bool]
    terms_text: Optional[str]

    class Config:
        orm_mode = True


class VendorTermDetail(BaseModel):
    terms_text: Optional[str]

    class Config:
        orm_mode = True


class VendorPrivacyPolicyDetail(BaseModel):
    description: Optional[str]

    class Config:
        orm_mode = True


class VendorPrivacyPolicy(VendorPrivacyPolicyDetail):
    active: Optional[bool]


class VendorContact(BaseModel):
    name: Optional[str]
    email: Optional[str]
    message: Optional[str]

    class Config:
        orm_mode = True


class ShowVendorContact(VendorContact):
    id: Optional[str]

    class Config:
        orm_mode = True


class VendorContactList(BaseModel):
    contacts: Optional[List[ShowVendorContact]]

    class Config:
        orm_mode = True


class VendorContactSetting(BaseModel):
    phone_number: Optional[str]
    email: Optional[str]
    location: Optional[str]

    class Config:
        orm_mode = True


class BaseVendorStyleDetail(BaseModel):
    id: Optional[str]
    name: Optional[str]
    name_ar: Optional[str]
    active: Optional[bool]
    admin_user_flag: Optional[bool]
    tenant: Optional[str]

    class Config():
        orm_mode = True


class VendorStyleDetail(BaseVendorStyleDetail):
    image: Optional[str]
    image_ar: Optional[str]


class VendorStyleCategorydetail(BaseVendorStyleDetail):
    thumb_image: Optional[str]
    styles: Optional[List[VendorStyleDetail]]

    class Config():
        orm_mode = True


class VendorFrontendDetail(BaseModel):
    header: Optional[VendorSetting]
    banner: Optional[VendorBannerDetail]
    banner_images: VendorBannerImagesInLanguages
    products: Optional[List[VendorProductDetail]]
    style_categories: Optional[List[VendorStyleCategorydetail]]
    faqs: Optional[List[VendorFaq]]
    term_conditions: Optional[VendorTermDetail]
    privacy_policy: Optional[VendorPrivacyPolicyDetail]
    contacts: Optional[List[VendorContact]]

    class Config:
        orm_mode = True


class country(BaseModel):
    id: int
    name: str
    iso2: str

    class Config:
        orm_mode = True


class States(BaseModel):
    id: int
    name: str
    state_code: str
    country_code: str

    class Config:
        orm_mode = True


class Cities(States):
    pass


class WhitelistIPDetail(BaseModel):
    whitelist_ip: str
    account_id: str
    created_at: datetime

    class Config:
        orm_mode = True
