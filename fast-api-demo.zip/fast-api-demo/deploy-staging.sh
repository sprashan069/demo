ssh -o StrictHostKeyChecking=no $STAGE_SERVER_USER@$STAGE_SERVER_IP  << 'ENDSSH'
  cd /home/ec2-user/microsite-staging
  export $(cat .env | xargs)
  docker login -u $CI_REGISTRY_USER -p $CI_JOB_TOKEN $CI_REGISTRY
  docker stop microsite-staging
  docker rm microsite-staging
  docker image rm $IMAGE:microsite-staging
  docker pull $IMAGE:microsite-staging
  docker run --name microsite-staging --env-file=.env -d -p 3000:8000 -p 80:8000 -p 443:8000 $IMAGE:microsite-staging
  docker exec microsite-staging alembic upgrade head
ENDSSH