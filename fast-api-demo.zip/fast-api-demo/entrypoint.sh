# Start Celery Workers
celery -A worker worker --loglevel=info &

# Start Celery Beat
celery -A worker beat --loglevel=info &

gunicorn app.main:app --keyfile=./privkey.pem --certfile=./cert.pem --bind 0.0.0.0:8000 -k uvicorn.workers.UvicornWorker --access-logfile '-'
