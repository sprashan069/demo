import os

from celery import Celery
from celery.schedules import crontab

BROKER_URI = os.environ.get("CELERY_BROKER_URL", "redis://localhost:6379")
BACKEND_URI = os.environ.get("CELERY_RESULT_BACKEND", "redis://localhost:6379")


app = Celery(
    'worker',
    broker=BROKER_URI,
    backend=BACKEND_URI,
    include=['app.crud.currency_rates', 'app.crud.accounts',
             'app.crud.vendor.vendor_account', 'app.crud.country_state_city']
)

app.conf.beat_schedule = {
    "run-me-every-day-for-currency-rates": {
        "task": "app.crud.currency_rates.currency_rate",
        "schedule": crontab(minute=0, hour=0)
    },
    "account_status": {
        "task": "app.crud.accounts.account_status",
        "schedule": crontab(minute=0, hour=0)
    },
    "save_csc_data": {
        "task": "app.crud.country_state_city.store_data",
        "schedule": crontab(minute=0, hour=0)
    }
}
