ssh -o StrictHostKeyChecking=no $STAGE_SERVER_USER@$STAGE_SERVER_IP  << 'ENDSSH'
  cd /home/ec2-user/microsite-dev
  export $(cat .env | xargs)
  docker login -u $CI_REGISTRY_USER -p $CI_JOB_TOKEN $CI_REGISTRY
  docker stop microsite-dev
  docker rm microsite-dev
  docker image rm $IMAGE:microsite-dev
  docker pull $IMAGE:microsite-dev
  docker run --name microsite-dev --env-file=.env -d -p 8080:8000 $IMAGE:microsite-dev
  docker exec microsite-dev alembic upgrade head
ENDSSH