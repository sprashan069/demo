"""change datatype of expiration period in MGC gift cards

Revision ID: d4a676775f6d
Revises: 7129747adbdb
Create Date: 2021-06-05 07:09:23.911668

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd4a676775f6d'
down_revision = '7129747adbdb'
branch_labels = None
depends_on = None

def upgrade():
    op.alter_column('merit_giftcards_version', 'expiration_date', existing_type=sa.Date(), type_=sa.String(100))

def downgrade():
    op.alter_column('merit_giftcards_version', 'expiration_date', existing_type=sa.String(100), type_=sa.Date())
