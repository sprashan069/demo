"""change datatype of expiration period in MGC gift cards

Revision ID: 7129747adbdb
Revises: 7acda13b73a4
Create Date: 2021-06-04 12:15:27.948693

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '7129747adbdb'
down_revision = '7acda13b73a4'
branch_labels = None
depends_on = None

def upgrade():
    op.alter_column('merit_giftcards', 'expiration_date', existing_type=sa.Date(), type_=sa.String(100))

def downgrade():
    op.alter_column('merit_giftcards', 'expiration_date', existing_type=sa.String(100), type_=sa.Date())
