"""FAILED added to order status

Revision ID: ae065d34af46
Revises: 010cf9e870a2
Create Date: 2021-06-08 12:30:55.328083

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'ae065d34af46'
down_revision = '010cf9e870a2'
branch_labels = None
depends_on = None


def upgrade():
    pass
    # with op.get_context().autocommit_block():
    #     op.execute("ALTER TYPE orderstatus ADD VALUE 'FAILED'")


def downgrade():
    pass
    # op.execute("ALTER TYPE orderstatus RENAME TO orderstatus_old")
    # op.execute("ALTER TYPE order_detail_status RENAME TO orderstatus_old")
    # op.execute("CREATE TYPE orderstatus AS ENUM('PENDING','PLACED','APPROVED','FULFILLED','AWAITING','IN_PROCESS','SHIPPED','DELIVERED','REDEEMED','REPROCESS','CANCELED')")
    # op.execute("DROP TYPE orderstatus_old")
    # op.execute("CREATE TYPE order_detail_status AS ENUM('PENDING','PLACED','APPROVED','FULFILLED','AWAITING','IN_PROCESS','SHIPPED','DELIVERED','REDEEMED','REPROCESS','CANCELED')")
    # op.execute("DROP TYPE orderstatus_old")
